package com.edisonsolar.businesspro;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context c){super(c,"edison_manager.db",null,2);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE companies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT)");
        d.execSQL("CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT,number TEXT,companyId INTEGER,company TEXT,customer TEXT,phone TEXT,site TEXT,kw REAL,amount REAL,date TEXT,status TEXT,work TEXT,lat REAL,lon REAL)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,projectId INTEGER,amount REAL,date TEXT,mode TEXT,note TEXT)");
        d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,projectId INTEGER,category TEXT,amount REAL,date TEXT,note TEXT)");
        d.execSQL("CREATE TABLE photos(id INTEGER PRIMARY KEY AUTOINCREMENT,projectId INTEGER,uri TEXT)");
    }
    public void onUpgrade(SQLiteDatabase d,int o,int n){
        if(o<2)d.execSQL("CREATE TABLE photos(id INTEGER PRIMARY KEY AUTOINCREMENT,projectId INTEGER,uri TEXT)");
    }
    private SQLiteDatabase w(){return getWritableDatabase();}
    private String q(String s){return s==null?"":s.replace("'","''");}
    public void addCompany(String n,String p){w().execSQL("INSERT INTO companies(name,phone) VALUES(?,?)",new Object[]{n,p});}
    public void updateCompany(int id,String n,String p){w().execSQL("UPDATE companies SET name=?,phone=? WHERE id=?",new Object[]{n,p,id});}
    public void deleteCompany(int id){w().execSQL("DELETE FROM companies WHERE id=?",new Object[]{id});}
    public ArrayList<Company> companies(){
        ArrayList<Company>a=new ArrayList<>(); Cursor c=w().rawQuery("SELECT id,name,phone FROM companies ORDER BY name",null);
        while(c.moveToNext())a.add(new Company(c.getInt(0),c.getString(1),c.getString(2)));c.close();return a;
    }
    public int nextProjectNo(){Cursor c=w().rawQuery("SELECT COUNT(*) FROM projects",null);int n=1;if(c.moveToFirst())n=c.getInt(0)+1;c.close();return n;}
    public void addProject(int cid,String cn,String cu,String ph,String site,double kw,double amount,String date,String status,String work){
        w().execSQL("INSERT INTO projects(number,companyId,company,customer,phone,site,kw,amount,date,status,work) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        new Object[]{String.format(Locale.US,"ES-%04d",nextProjectNo()),cid,cn,cu,ph,site,kw,amount,date,status,work});
    }
    public void updateProject(Project p,int cid,String cn,String cu,String ph,String site,double kw,double amount,String date,String status,String work){
        w().execSQL("UPDATE projects SET companyId=?,company=?,customer=?,phone=?,site=?,kw=?,amount=?,date=?,status=?,work=? WHERE id=?",
        new Object[]{cid,cn,cu,ph,site,kw,amount,date,status,work,p.id});
    }
    public void deleteProject(int id){
        w().execSQL("DELETE FROM payments WHERE projectId=?",new Object[]{id});
        w().execSQL("DELETE FROM expenses WHERE projectId=?",new Object[]{id});
        w().execSQL("DELETE FROM photos WHERE projectId=?",new Object[]{id});
        w().execSQL("DELETE FROM projects WHERE id=?",new Object[]{id});
    }
    public void setLocation(int id,double lat,double lon){w().execSQL("UPDATE projects SET lat=?,lon=? WHERE id=?",new Object[]{lat,lon,id});}
    public ArrayList<Project> projects(){
        ArrayList<Project>a=new ArrayList<>();Cursor c=w().rawQuery("SELECT * FROM projects ORDER BY id DESC",null);
        while(c.moveToNext())a.add(Project.from(c));c.close();return a;
    }
    public Project project(int id){
        Cursor c=w().rawQuery("SELECT * FROM projects WHERE id=?",new String[]{""+id});
        Project p=c.moveToFirst()?Project.from(c):null;c.close();return p;
    }
    public void addPayment(int pid,double amount,String date,String mode,String note){w().execSQL("INSERT INTO payments(projectId,amount,date,mode,note) VALUES(?,?,?,?,?)",new Object[]{pid,amount,date,mode,note});}
    public void updatePayment(Payment p,double amount,String date,String mode,String note){w().execSQL("UPDATE payments SET amount=?,date=?,mode=?,note=? WHERE id=?",new Object[]{amount,date,mode,note,p.id});}
    public void deletePayment(int id){w().execSQL("DELETE FROM payments WHERE id=?",new Object[]{id});}
    public ArrayList<Payment> payments(){
        ArrayList<Payment>a=new ArrayList<>();Cursor c=w().rawQuery("SELECT p.id,p.projectId,pr.number,p.amount,p.date,p.mode,p.note FROM payments p JOIN projects pr ON pr.id=p.projectId ORDER BY p.id DESC",null);
        while(c.moveToNext())a.add(new Payment(c.getInt(0),c.getInt(1),c.getString(2),c.getDouble(3),c.getString(4),c.getString(5),c.getString(6)));c.close();return a;
    }
    public void addExpense(int pid,String cat,double amount,String date,String note){w().execSQL("INSERT INTO expenses(projectId,category,amount,date,note) VALUES(?,?,?,?,?)",new Object[]{pid,cat,amount,date,note});}
    public void updateExpense(Expense e,String cat,double amount,String date,String note){w().execSQL("UPDATE expenses SET category=?,amount=?,date=?,note=? WHERE id=?",new Object[]{cat,amount,date,note,e.id});}
    public void deleteExpense(int id){w().execSQL("DELETE FROM expenses WHERE id=?",new Object[]{id});}
    public ArrayList<Expense> expenses(){
        ArrayList<Expense>a=new ArrayList<>();Cursor c=w().rawQuery("SELECT e.id,e.projectId,p.number,e.category,e.amount,e.date,e.note FROM expenses e JOIN projects p ON p.id=e.projectId ORDER BY e.id DESC",null);
        while(c.moveToNext())a.add(new Expense(c.getInt(0),c.getInt(1),c.getString(2),c.getString(3),c.getDouble(4),c.getString(5),c.getString(6)));c.close();return a;
    }
    public void addPhoto(int pid,String uri){w().execSQL("INSERT INTO photos(projectId,uri) VALUES(?,?)",new Object[]{pid,uri});}
    public void deletePhoto(int id){w().execSQL("DELETE FROM photos WHERE id=?",new Object[]{id});}
    public ArrayList<Photo> photos(int pid){
        ArrayList<Photo>a=new ArrayList<>();Cursor c=w().rawQuery("SELECT id,projectId,uri FROM photos WHERE projectId=? ORDER BY id",new String[]{""+pid});
        while(c.moveToNext())a.add(new Photo(c.getInt(0),c.getInt(1),c.getString(2)));c.close();return a;
    }
    private double scalar(String sql,String[] args){Cursor c=w().rawQuery(sql,args);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double collection(int pid){return scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE projectId=?",new String[]{""+pid});}
    public double expenses(int pid){return scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE projectId=?",new String[]{""+pid});}
    public double pending(int pid){Project p=project(pid);return p==null?0:Math.max(0,p.amount-collection(pid));}
    public double profit(int pid){Project p=project(pid);return p==null?0:p.amount-expenses(pid);}
    public int countProjects(int cid){return (int)scalar("SELECT COUNT(*) FROM projects WHERE companyId=?",new String[]{""+cid});}
    public double companyKw(int cid){return scalar("SELECT COALESCE(SUM(kw),0) FROM projects WHERE companyId=?",new String[]{""+cid});}
    public double companyValue(int cid){return scalar("SELECT COALESCE(SUM(amount),0) FROM projects WHERE companyId=?",new String[]{""+cid});}
    public double companyCollection(int cid){return scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE projectId IN (SELECT id FROM projects WHERE companyId=?)",new String[]{""+cid});}
    public double companyExpenses(int cid){return scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE projectId IN (SELECT id FROM projects WHERE companyId=?)",new String[]{""+cid});}
    public String dashboard(){
        double kw=0,val=0,col=0,ex=0;for(Project p:projects()){kw+=p.kw;val+=p.amount;col+=collection(p.id);ex+=expenses(p.id);}
        return "Companies: "+companies().size()+"\nProjects: "+projects().size()+"\nTotal kW: "+fmt(kw)+"\nProject Value: ₹"+fmt(val)+"\nCollection: ₹"+fmt(col)+"\nPending: ₹"+fmt(Math.max(0,val-col))+"\nExpenses: ₹"+fmt(ex)+"\nProfit: ₹"+fmt(val-ex);
    }
    public static String fmt(double x){return String.format(Locale.getDefault(),"%.2f",x);}
}
class Company {int id;String name,phone;Company(int i,String n,String p){id=i;name=n;phone=p;}}
class Project {
    int id,companyId;String number,company,customer,phone,site,date,status,work;double kw,amount,lat,lon;boolean hasLoc;
    static Project from(Cursor c){
        Project p=new Project();p.id=c.getInt(0);p.number=c.getString(1);p.companyId=c.getInt(2);p.company=c.getString(3);p.customer=c.getString(4);p.phone=c.getString(5);p.site=c.getString(6);p.kw=c.getDouble(7);p.amount=c.getDouble(8);p.date=c.getString(9);p.status=c.getString(10);p.work=c.getString(11);
        if(!c.isNull(12)){p.lat=c.getDouble(12);p.lon=c.getDouble(13);p.hasLoc=true;}return p;
    }
}
class Payment {int id,projectId;String project,date,mode,note;double amount;Payment(int i,int pi,String pr,double a,String d,String m,String n){id=i;projectId=pi;project=pr;amount=a;date=d;mode=m;note=n;}}
class Expense {int id,projectId;String project,category,date,note;double amount;Expense(int i,int pi,String pr,String c,double a,String d,String n){id=i;projectId=pi;project=pr;category=c;amount=a;date=d;note=n;}}
class Photo {int id,projectId;String uri;Photo(int i,int p,String u){id=i;projectId=p;uri=u;}}
