package com.edisonsolar.businesspro;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.location.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    DBHelper db; LinearLayout root; int blue=Color.rgb(11,94,215),green=Color.rgb(25,135,84),orange=Color.rgb(240,138,36),purple=Color.rgb(111,66,193),red=Color.rgb(220,53,69),dark=Color.rgb(23,50,77),bg=Color.rgb(245,249,253);
    Project currentProjectForPhoto; Uri cameraUri; static final int LOC=100,CAMERA=101,GALLERY=102,CAPTURE=103;

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DBHelper(this);getWindow().setStatusBarColor(Color.WHITE);showHome();}
    TextView tv(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(dark);t.setPadding(16,12,16,12);return t;}
    void base(String title){
        ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,30);root.setBackgroundColor(bg);
        sv.addView(root);setContentView(sv);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        Button back=new Button(this);back.setText("‹");back.setTextSize(28);back.setOnClickListener(v->showHome());bar.addView(back,new LinearLayout.LayoutParams(55,55));
        TextView tt=tv(title,21);tt.setTypeface(null,1);bar.addView(tt,new LinearLayout.LayoutParams(0,55,1));root.addView(bar);
    }
    void logo(){ImageView im=new ImageView(this);int id=getResources().getIdentifier("edison_solar_logo","drawable",getPackageName());if(id!=0)im.setImageResource(id);im.setAdjustViewBounds(true);root.addView(im,new LinearLayout.LayoutParams(-1,135));}
    Button btn(String s,int color,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setAllCaps(false);b.setOnClickListener(l);GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(18);b.setBackground(g);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,54);p.setMargins(0,6,0,6);b.setLayoutParams(p);return b;}
    TextView card(String s){TextView t=tv(s,15);t.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,5);t.setLayoutParams(p);return t;}
    EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setPadding(12,8,12,8);return e;}
    String today(){return new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date());}

    void showHome(){
        base("EDISON SOLAR MANAGER PRO");logo();root.addView(card(db.dashboard()));
        root.addView(btn("🏢 Companies",blue,v->companies()));
        root.addView(btn("☀️ Projects",blue,v->projects()));
        root.addView(btn("💰 Payment Collection",green,v->payments()));
        root.addView(btn("🧾 Expenses",orange,v->expenses()));
        root.addView(btn("📅 Calendar",purple,v->calendar()));
        root.addView(btn("📊 Reports / PDF",purple,v->reports()));
        root.addView(btn("📱 WhatsApp Report",green,v->shareText(db.dashboard())));
    }

    void companies(){
        base("Companies");root.addView(btn("+ Add Company",blue,v->companyDialog(null)));
        for(Company c:db.companies()){
            String s=c.name+"\nPhone: "+c.phone+"\nProjects: "+db.countProjects(c.id)+" | kW: "+DBHelper.fmt(db.companyKw(c.id))+
                    "\nCollection: ₹"+DBHelper.fmt(db.companyCollection(c.id))+" | Expenses: ₹"+DBHelper.fmt(db.companyExpenses(c.id))+
                    "\nPending: ₹"+DBHelper.fmt(db.companyValue(c.id)-db.companyCollection(c.id))+" | Profit: ₹"+DBHelper.fmt(db.companyValue(c.id)-db.companyExpenses(c.id));
            root.addView(card(s));
            LinearLayout row=new LinearLayout(this);row.addView(btn("Edit",blue,v->companyDialog(c)),new LinearLayout.LayoutParams(0,52,1));row.addView(btn("Delete",red,v->{confirm("Delete company?",()->{db.deleteCompany(c.id);companies();});}),new LinearLayout.LayoutParams(0,52,1));root.addView(row);
            root.addView(btn("Company Report / WhatsApp",purple,v->shareText(companyReport(c))));
        }
    }
    String companyReport(Company c){StringBuilder s=new StringBuilder(c.name+"\nPhone: "+c.phone+"\n\n");for(Project p:db.projects())if(p.companyId==c.id)s.append(p.number+" | "+p.customer+" | "+p.kw+" kW\n₹"+p.amount+" | Collection ₹"+db.collection(p.id)+" | Pending ₹"+db.pending(p.id)+" | Expenses ₹"+db.expenses(p.id)+" | Profit ₹"+db.profit(p.id)+"\n"+p.site+"\n\n");return s.toString();}

    void companyDialog(Company old){
        LinearLayout l=vertical();EditText n=field("Company Name",old==null?"":old.name),p=field("Phone",old==null?"":old.phone);l.addView(n);l.addView(p);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(old==null?"Add Company":"Edit Company").setView(l).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{if(n.getText().toString().trim().isEmpty()){n.setError("Required");return;}if(old==null)db.addCompany(n.getText().toString(),p.getText().toString());else db.updateCompany(old.id,n.getText().toString(),p.getText().toString());d.dismiss();companies();}));d.show();
    }

    void projects(){
        base("Projects");root.addView(btn("+ Add Project",blue,v->projectDialog(null)));
        for(Project p:db.projects()){
            root.addView(card(p.number+" • "+p.company+"\nCustomer: "+p.customer+" | "+p.kw+" kW\nSite: "+p.site+"\nAmount: ₹"+DBHelper.fmt(p.amount)+" | Collection: ₹"+DBHelper.fmt(db.collection(p.id))+" | Pending: ₹"+DBHelper.fmt(db.pending(p.id))+
                    "\nExpenses: ₹"+DBHelper.fmt(db.expenses(p.id))+" | Site Profit: ₹"+DBHelper.fmt(db.profit(p.id))+"\n"+p.date+" • "+p.status));
            root.addView(btn("Open Project",blue,v->projectMenu(p)));
        }
    }

    void projectMenu(Project p){
        new AlertDialog.Builder(this).setTitle(p.number+" • "+p.customer).setItems(new String[]{"Edit Project","Payments","Expenses","Photos / Gallery","GPS / Google Map","PDF Report","WhatsApp Report","Delete Project"},(d,w)->{
            if(w==0)projectDialog(p);else if(w==1)projectPayments(p);else if(w==2)projectExpenses(p);else if(w==3)photos(p);else if(w==4)gpsMap(p);else if(w==5)createPdf(p);else if(w==6)shareText(projectReport(p));else confirm("Delete this project and its records?",()->{db.deleteProject(p.id);projects();});
        }).show();
    }
    String projectReport(Project p){return "EDISON SOLAR MANAGER PRO\n"+p.number+"\nCompany: "+p.company+"\nCustomer: "+p.customer+"\nPhone: "+p.phone+"\nSite: "+p.site+"\nSolar: "+p.kw+" kW\nProject Amount: ₹"+DBHelper.fmt(p.amount)+"\nCollection: ₹"+DBHelper.fmt(db.collection(p.id))+"\nPending: ₹"+DBHelper.fmt(db.pending(p.id))+"\nExpenses: ₹"+DBHelper.fmt(db.expenses(p.id))+"\nSite Profit: ₹"+DBHelper.fmt(db.profit(p.id))+"\nDate: "+p.date+"\nStatus: "+p.status+"\nWork: "+p.work;}

    void projectDialog(Project old){
        ArrayList<Company> cs=db.companies();if(cs.isEmpty()){Toast.makeText(this,"Add company first",Toast.LENGTH_LONG).show();return;}
        LinearLayout l=vertical();Spinner sp=new Spinner(this);ArrayList<String> names=new ArrayList<>();for(Company c:cs)names.add(c.name);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));
        if(old!=null)for(int i=0;i<cs.size();i++)if(cs.get(i).id==old.companyId)sp.setSelection(i);
        EditText cu=field("Customer Name",old==null?"":old.customer),ph=field("Customer Phone",old==null?"":old.phone),site=field("Site Address",old==null?"":old.site),kw=field("Solar kW",old==null?"":""+old.kw),amt=field("Project Amount",old==null?"":""+old.amount),date=field("Installation Date",old==null?today():old.date),work=field("Site Work Detail",old==null?"":old.work);kw.setInputType(2);amt.setInputType(2);
        RadioGroup rg=new RadioGroup(this);RadioButton a=new RadioButton(this);a.setText("Pending");RadioButton b=new RadioButton(this);b.setText("Work Going On");rg.addView(a);rg.addView(b);if(old!=null&&"Work Going On".equals(old.status))b.setChecked(true);else a.setChecked(true);
        l.addView(sp);l.addView(cu);l.addView(ph);l.addView(site);l.addView(kw);l.addView(amt);l.addView(date);l.addView(rg);l.addView(work);
        Button dateBtn=new Button(this);dateBtn.setText("📅 Choose Installation Date");dateBtn.setOnClickListener(v->datePicker(date));l.addView(dateBtn);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(old==null?"New Project":"Edit Project").setView(l).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{Company c=cs.get(sp.getSelectedItemPosition());double k=num(kw),money=num(amt);if(cu.getText().toString().trim().isEmpty()){cu.setError("Required");return;}if(old==null)db.addProject(c.id,c.name,cu.getText().toString(),ph.getText().toString(),site.getText().toString(),k,money,date.getText().toString(),b.isChecked()?"Work Going On":"Pending",work.getText().toString());else db.updateProject(old,c.id,c.name,cu.getText().toString(),ph.getText().toString(),site.getText().toString(),k,money,date.getText().toString(),b.isChecked()?"Work Going On":"Pending",work.getText().toString());d.dismiss();projects();}));d.show();
    }

    void projectPayments(Project p){base("Payments • "+p.number);root.addView(btn("+ Add Payment",green,v->paymentDialog(p,null)));for(Payment x:db.payments())if(x.projectId==p.id){root.addView(card("₹"+DBHelper.fmt(x.amount)+" • "+x.date+" • "+x.mode+"\n"+x.note));root.addView(btn("Edit",blue,v->paymentDialog(p,x)));root.addView(btn("Delete",red,v->{db.deletePayment(x.id);projectPayments(p);}));}root.addView(card("Collection: ₹"+DBHelper.fmt(db.collection(p.id))+"\nPending: ₹"+DBHelper.fmt(db.pending(p.id))));}
    void paymentDialog(Project p,Payment old){LinearLayout l=vertical();EditText a=field("Amount",old==null?"":""+old.amount),d=field("Date",old==null?today():old.date),m=field("Mode",old==null?"UPI":old.mode),n=field("Note",old==null?"":old.note);l.addView(a);l.addView(d);l.addView(m);l.addView(n);AlertDialog q=new AlertDialog.Builder(this).setTitle(old==null?"Add Payment":"Edit Payment").setView(l).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();q.setOnShowListener(z->q.getButton(-1).setOnClickListener(v->{if(old==null)db.addPayment(p.id,num(a),d.getText().toString(),m.getText().toString(),n.getText().toString());else db.updatePayment(old,num(a),d.getText().toString(),m.getText().toString(),n.getText().toString());q.dismiss();projectPayments(p);}));q.show();}

    void projectExpenses(Project p){base("Expenses • "+p.number);root.addView(btn("+ Add Expense",orange,v->expenseDialog(p,null)));for(Expense x:db.expenses())if(x.projectId==p.id){root.addView(card(x.category+" • ₹"+DBHelper.fmt(x.amount)+" • "+x.date+"\n"+x.note));root.addView(btn("Edit",blue,v->expenseDialog(p,x)));root.addView(btn("Delete",red,v->{db.deleteExpense(x.id);projectExpenses(p);}));}root.addView(card("Total Expenses: ₹"+DBHelper.fmt(db.expenses(p.id))+"\nSite Profit: ₹"+DBHelper.fmt(db.profit(p.id))));}
    void expenseDialog(Project p,Expense old){LinearLayout l=vertical();Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Salary","Tea","Lunch","Transportation","Other"}));String[] cats={"Salary","Tea","Lunch","Transportation","Other"};if(old!=null)for(int i=0;i<cats.length;i++)if(cats[i].equals(old.category))s.setSelection(i);EditText a=field("Amount",old==null?"":""+old.amount),d=field("Date",old==null?today():old.date),n=field("Note",old==null?"":old.note);l.addView(s);l.addView(a);l.addView(d);l.addView(n);AlertDialog q=new AlertDialog.Builder(this).setTitle(old==null?"Add Expense":"Edit Expense").setView(l).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();q.setOnShowListener(z->q.getButton(-1).setOnClickListener(v->{if(old==null)db.addExpense(p.id,s.getSelectedItem().toString(),num(a),d.getText().toString(),n.getText().toString());else db.updateExpense(old,s.getSelectedItem().toString(),num(a),d.getText().toString(),n.getText().toString());q.dismiss();projectExpenses(p);}));q.show();}

    void payments(){base("Payment Collection");root.addView(btn("+ Add Payment",green,v->{ArrayList<Project>ps=db.projects();if(ps.isEmpty()){Toast.makeText(this,"Add project first",Toast.LENGTH_SHORT).show();return;}projectPayments(ps.get(0));}));for(Payment x:db.payments()){root.addView(card(x.project+" • ₹"+DBHelper.fmt(x.amount)+"\n"+x.date+" • "+x.mode+"\n"+x.note));root.addView(btn("Delete",red,v->{db.deletePayment(x.id);payments();}));}}
    void expenses(){base("Expenses");root.addView(btn("Manage Project Expenses",orange,v->{ArrayList<Project>ps=db.projects();if(ps.isEmpty()){Toast.makeText(this,"Add project first",Toast.LENGTH_SHORT).show();return;}projectExpenses(ps.get(0));}));for(Expense x:db.expenses())root.addView(card(x.project+" • "+x.category+" • ₹"+DBHelper.fmt(x.amount)+"\n"+x.date+" • "+x.note));}

    void calendar(){base("Calendar");Calendar cal=Calendar.getInstance();DatePicker dp=new DatePicker(this);dp.init(cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH),(v,y,m,d)->showDateResults(String.format(Locale.US,"%02d-%02d-%04d",d,m+1,y)));root.addView(dp,new LinearLayout.LayoutParams(-1,300));root.addView(card("Tap a date above to view company / project / customer / site / kW / status / payment / expenses / profit."));showDateResults(today());}
    void showDateResults(String date){for(Project p:db.projects())if(date.equals(p.date)){root.addView(card(p.company+" • "+p.number+"\n"+p.customer+" • "+p.kw+" kW\n"+p.site+"\nStatus: "+p.status+"\nPayment: ₹"+DBHelper.fmt(db.collection(p.id))+"\nExpenses: ₹"+DBHelper.fmt(db.expenses(p.id))+"\nProfit: ₹"+DBHelper.fmt(db.profit(p.id)));}}

    void reports(){base("Reports / PDF");root.addView(card(db.dashboard()));root.addView(btn("Full Business PDF",purple,v->createFullPdf()));root.addView(btn("WhatsApp Full Report",green,v->shareText(db.dashboard()+"\n\n"+allReports())));for(Company c:db.companies())root.addView(btn(c.name+" PDF",purple,v->createCompanyPdf(c)));}
    String allReports(){StringBuilder s=new StringBuilder();for(Project p:db.projects())s.append("\n").append(projectReport(p)).append("\n");return s.toString();}

    void photos(Project p){base("Photos • "+p.number);root.addView(btn("📷 Take Photo",blue,v->{currentProjectForPhoto=p;takePhoto();}));root.addView(btn("🖼 Add From Gallery",purple,v->{currentProjectForPhoto=p;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,GALLERY);}));for(Photo x:db.photos(p.id)){ImageView im=new ImageView(this);try{im.setImageURI(Uri.parse(x.uri));}catch(Exception ignored){}im.setAdjustViewBounds(true);root.addView(im,new LinearLayout.LayoutParams(-1,260));root.addView(btn("Delete Photo",red,v->{db.deletePhoto(x.id);photos(p);}));}}
    void takePhoto(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAMERA);return;}try{File f=new File(getExternalFilesDir("Pictures"),"photo_"+System.currentTimeMillis()+".jpg");cameraUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,CAPTURE);}catch(Exception e){Toast.makeText(this,"Camera error: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||currentProjectForPhoto==null)return;if(r==CAPTURE){db.addPhoto(currentProjectForPhoto.id,cameraUri.toString());photos(currentProjectForPhoto);}else if(r==GALLERY&&d!=null){if(d.getClipData()!=null){for(int i=0;i<d.getClipData().getItemCount();i++)saveUri(d.getClipData().getItemAt(i).getUri());}else if(d.getData()!=null)saveUri(d.getData());photos(currentProjectForPhoto);}}
    void saveUri(Uri u){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}db.addPhoto(currentProjectForPhoto.id,u.toString());}

    void gpsMap(Project p){if(p.hasLoc)new AlertDialog.Builder(this).setTitle("GPS Location").setMessage(p.lat+", "+p.lon).setPositiveButton("Open Google Map",(_d,w)->openMap(p.lat,p.lon)).setNegativeButton("Close",null).setNeutralButton("Update GPS",(_d,w)->requestLocation(p)).show();else requestLocation(p);}
    void requestLocation(Project p){if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOC);Toast.makeText(this,"Location permission requested. Open GPS again after allowing.",Toast.LENGTH_LONG).show();return;}LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);Location loc=null;try{loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(loc==null)loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);}catch(SecurityException ignored){}if(loc==null){Toast.makeText(this,"Turn on GPS and try again.",Toast.LENGTH_LONG).show();return;}db.setLocation(p.id,loc.getLatitude(),loc.getLongitude());p=db.project(p.id);openMap(p.lat,p.lon);}
    void openMap(double lat,double lon){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q="+lat+","+lon));i.setPackage("com.google.android.apps.maps");startActivity(i);}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:"+lat+","+lon+"?q="+lat+","+lon)));}}

    void createPdf(Project p){ArrayList<String> lines=new ArrayList<>(Arrays.asList(projectReport(p).split("\n")));sharePdf("Project_"+p.number+".pdf","EDISON SOLAR MANAGER PRO - "+p.number,lines);}
    void createCompanyPdf(Company c){ArrayList<String>lines=new ArrayList<>();lines.add(c.name);lines.add("Phone: "+c.phone);for(Project p:db.projects())if(p.companyId==c.id)lines.addAll(Arrays.asList(projectReport(p).split("\n")));sharePdf("Company_"+safe(c.name)+".pdf","Company Report - "+c.name,lines);}
    void createFullPdf(){ArrayList<String>lines=new ArrayList<>(Arrays.asList(db.dashboard().split("\n")));for(Project p:db.projects()){lines.add("");lines.addAll(Arrays.asList(projectReport(p).split("\n")));}sharePdf("EDISON_FULL_REPORT.pdf","EDISON SOLAR MANAGER PRO",lines);}
    void sharePdf(String name,String title,ArrayList<String>lines){try{File dir=new File(getCacheDir(),"shared");dir.mkdirs();File f=new File(dir,name);PdfDocument pdf=new PdfDocument();Paint paint=new Paint();paint.setTextSize(11);int pageNo=1,y=45;PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());Canvas can=page.getCanvas();can.drawText(title,35,y,paint);y+=25;for(String line:lines){for(String piece:wrap(line,75)){if(y>800){pdf.finishPage(page);page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());can=page.getCanvas();y=45;}can.drawText(piece,35,y,paint);y+=18;}}pdf.finishPage(page);FileOutputStream out=new FileOutputStream(f);pdf.writeTo(out);out.close();pdf.close();Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Send PDF"));}catch(Exception e){Toast.makeText(this,"PDF error: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    ArrayList<String>wrap(String s,int n){ArrayList<String>a=new ArrayList<>();while(s.length()>n){int cut=s.lastIndexOf(' ',n);if(cut<1)cut=n;a.add(s.substring(0,cut));s=s.substring(cut).trim();}a.add(s);return a;}
    String safe(String s){return s.replaceAll("[^A-Za-z0-9_-]","_");}

    void datePicker(EditText e){Calendar c=Calendar.getInstance();new DatePickerDialog(this,(v,y,m,d)->e.setText(String.format(Locale.US,"%02d-%02d-%04d",d,m+1,y)),c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    double num(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(22,5,22,5);return l;}
    void confirm(String msg,Runnable yes){new AlertDialog.Builder(this).setMessage(msg).setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->yes.run()).show();}
    void shareText(String s){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Share / WhatsApp"));}
}
