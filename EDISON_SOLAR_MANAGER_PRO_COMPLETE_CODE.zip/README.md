# EDISON SOLAR MANAGER PRO — COMPLETE BUILD

Application ID: `com.edisonsolar.businesspro`

Separate app; old EDISON package is not used.

Implemented:
- Approved EDISON SOLAR logo
- Companies: add/edit/delete, company totals and report
- Projects: add/edit/delete, auto project number, company/customer/site/kW/amount/date/status/work detail
- Payment collection: add/edit/delete, payment history, collection and pending
- Expenses: Salary, Tea, Lunch, Transportation, Other; add/edit/delete
- Site profit: Project Amount - Site Expenses
- Calendar: date-wise company/project/customer/site/kW/status/payment/expenses/profit
- GPS: save current location and open Google Maps
- Project photos: camera + multi-image gallery + delete
- PDF: project/company/full-business reports
- WhatsApp/share: text report and PDF share intent
- Offline SQLite database
- Android safe scroll layout and branded buttons
- No Stock module

Build:
1. Open the folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

No Firebase/cloud credentials are included. This version is offline/local by design.
