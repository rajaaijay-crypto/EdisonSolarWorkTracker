package com.edisonsolar.attendance

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.location.LocationManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class Worker(
    val id: Long, val name: String, val phone: String,
    val salary: Double, val paymentType: String, val role: String
)
data class Att(
    val status: String, val inTime: String, val outTime: String,
    val site: String, val note: String, val lat: Double, val lon: Double
)
data class Adv(
    val id: Long, val workerId: Long, val amount: Double,
    val date: String, val note: String
)

class DBHelper(c: Context) : android.database.sqlite.SQLiteOpenHelper(c, "edison.db", null, 7) {
    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL("""CREATE TABLE workers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, phone TEXT, salary REAL DEFAULT 0,
            payment_type TEXT DEFAULT 'Daily', role TEXT)""")
        db.execSQL("""CREATE TABLE attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER NOT NULL, date TEXT NOT NULL,
            status TEXT NOT NULL, intime TEXT, outtime TEXT,
            site TEXT, note TEXT, latitude REAL DEFAULT 0,
            longitude REAL DEFAULT 0, UNIQUE(worker_id,date))""")
        db.execSQL("""CREATE TABLE advances(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER NOT NULL, amount REAL NOT NULL,
            date TEXT NOT NULL, note TEXT)""")
    }
    override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, old: Int, new: Int) {
        if (old < 5) {
            try { db.execSQL("ALTER TABLE workers ADD COLUMN payment_type TEXT DEFAULT 'Daily'") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE workers ADD COLUMN role TEXT") } catch (_: Exception) {}
        }
        if (old < 6) {
            try { db.execSQL("ALTER TABLE attendance ADD COLUMN latitude REAL DEFAULT 0") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE attendance ADD COLUMN longitude REAL DEFAULT 0") } catch (_: Exception) {}
        }
    }
    fun workers(): List<Worker> {
        val out = mutableListOf<Worker>()
        readableDatabase.rawQuery("SELECT * FROM workers ORDER BY name", null).use { c ->
            while (c.moveToNext()) out.add(
                Worker(
                    c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("name")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("phone")) ?: "",
                    c.getDouble(c.getColumnIndexOrThrow("salary")),
                    c.getString(c.getColumnIndexOrThrow("payment_type")) ?: "Daily",
                    c.getString(c.getColumnIndexOrThrow("role")) ?: ""
                )
            )
        }
        return out
    }
    fun addWorker(w: Worker) {
        val v = ContentValues().apply {
            put("name", w.name.trim()); put("phone", w.phone.trim())
            put("salary", w.salary); put("payment_type", w.paymentType); put("role", w.role.trim())
        }
        writableDatabase.insert("workers", null, v)
    }
    fun updateWorker(w: Worker) {
        val v = ContentValues().apply {
            put("name", w.name.trim()); put("phone", w.phone.trim())
            put("salary", w.salary); put("payment_type", w.paymentType); put("role", w.role.trim())
        }
        writableDatabase.update("workers", v, "id=?", arrayOf(w.id.toString()))
    }
    fun deleteWorker(id: Long) {
        writableDatabase.delete("attendance", "worker_id=?", arrayOf(id.toString()))
        writableDatabase.delete("advances", "worker_id=?", arrayOf(id.toString()))
        writableDatabase.delete("workers", "id=?", arrayOf(id.toString()))
    }
    fun attendance(worker: Long, date: String): Att? {
        readableDatabase.query("attendance", null, "worker_id=? AND date=?",
            arrayOf(worker.toString(), date), null, null, null).use { c ->
            if (c.moveToFirst()) return Att(
                c.getString(c.getColumnIndexOrThrow("status")) ?: "Absent",
                c.getString(c.getColumnIndexOrThrow("intime")) ?: "",
                c.getString(c.getColumnIndexOrThrow("outtime")) ?: "",
                c.getString(c.getColumnIndexOrThrow("site")) ?: "",
                c.getString(c.getColumnIndexOrThrow("note")) ?: "",
                c.getDouble(c.getColumnIndexOrThrow("latitude")),
                c.getDouble(c.getColumnIndexOrThrow("longitude"))
            )
        }
        return null
    }
    fun saveAttendance(worker: Long, date: String, status: String, inTime: String,
                       outTime: String, site: String, note: String, lat: Double, lon: Double) {
        val v = ContentValues().apply {
            put("worker_id", worker); put("date", date)
            put("status", if (status == "Present" || status == "Half Day") status else "Absent")
            put("intime", inTime.trim()); put("outtime", outTime.trim())
            put("site", site.trim()); put("note", note.trim())
            put("latitude", lat); put("longitude", lon)
        }
        writableDatabase.insertWithOnConflict(
            "attendance", null, v,
            android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE
        )
    }
    fun advances(worker: Long): List<Adv> {
        val out = mutableListOf<Adv>()
        readableDatabase.rawQuery(
            "SELECT * FROM advances WHERE worker_id=? ORDER BY date DESC,id DESC",
            arrayOf(worker.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(
                Adv(
                    c.getLong(c.getColumnIndexOrThrow("id")), worker,
                    c.getDouble(c.getColumnIndexOrThrow("amount")),
                    c.getString(c.getColumnIndexOrThrow("date")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("note")) ?: ""
                )
            )
        }
        return out
    }
    fun saveAdvance(a: Adv) {
        val v = ContentValues().apply {
            put("worker_id", a.workerId); put("amount", a.amount)
            put("date", a.date); put("note", a.note.trim())
        }
        if (a.id == 0L) writableDatabase.insert("advances", null, v)
        else writableDatabase.update("advances", v, "id=?", arrayOf(a.id.toString()))
    }
    fun deleteAdvance(id: Long) { writableDatabase.delete("advances", "id=?", arrayOf(id.toString())) }
    fun advanceTotal(worker: Long): Double {
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(amount),0) FROM advances WHERE worker_id=?",
            arrayOf(worker.toString())
        ).use { c -> if (c.moveToFirst()) return c.getDouble(0) }
        return 0.0
    }
    fun monthCounts(worker: Long, year: Int, month: Int): Pair<Int, Int> {
        val prefix = String.format(Locale.getDefault(), "%04d-%02d-", year, month + 1)
        var p = 0; var h = 0
        readableDatabase.rawQuery(
            "SELECT status FROM attendance WHERE worker_id=? AND date LIKE ?",
            arrayOf(worker.toString(), "$prefix%")
        ).use { c ->
            while (c.moveToNext()) when (c.getString(0)) {
                "Present" -> p++
                "Half Day" -> h++
            }
        }}
        return Pair(p, h)
    }
}

class MainActivity : Activity() {
    private lateinit var db: DBHelper
    private lateinit var content: LinearLayout
    private var selectedDate = today()
    private var reportMonth = Calendar.getInstance()
    private val blue = Color.rgb(25,118,210)
    private val dark = Color.rgb(13,71,161)
    private val green = Color.rgb(46,125,50)
    private val red = Color.rgb(198,40,40)
    private val orange = Color.rgb(239,108,0)
    private val light = Color.rgb(235,245,255)

    companion object {
        const val LOCATION = 900
        fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        fun d(s:String) = try {
            val a=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault())
            val b=SimpleDateFormat("dd-MM-yyyy",Locale.getDefault())
            b.format(a.parse(s)!!)
        } catch(_:Exception){s}
    }

    override fun onCreate(b: Bundle?) { super.onCreate(b); db=DBHelper(this); home() }
    private fun dp(n:Int)= (n*resources.displayMetrics.density).toInt()
    private fun base(title:String):LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL
        val head=TextView(this); head.text="⚡ EDISON  $title"; head.textSize=18f
        head.setTextColor(Color.WHITE); head.gravity=Gravity.CENTER_VERTICAL; head.setPadding(dp(12),0,0,0); head.setBackgroundColor(blue)
        root.addView(head,LinearLayout.LayoutParams(-1,dp(52)))
        val sc=ScrollView(this); content=LinearLayout(this); content.orientation=LinearLayout.VERTICAL; content.setPadding(dp(8),dp(8),dp(8),dp(8)); sc.addView(content)
        root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this); nav.orientation=LinearLayout.HORIZONTAL; nav.setBackgroundColor(light)
        navBtn(nav,"HOME"){home()}; navBtn(nav,"WORKERS"){workers()}; navBtn(nav,"CALENDAR"){attendance()}; navBtn(nav,"SALARY"){salary()}
        root.addView(nav,LinearLayout.LayoutParams(-1,dp(48))); return root
    }
    private fun navBtn(p:LinearLayout,t:String,a:()->Unit){val b=Button(this);b.text=t;b.textSize=10f;b.setPadding(0,0,0,0);b.setOnClickListener{a()};p.addView(b,LinearLayout.LayoutParams(0,dp(44),1f))}
    private fun button(t:String,a:()->Unit):Button{val b=Button(this);b.text=t;b.textSize=13f;b.minHeight=dp(42);b.setOnClickListener{a()};return b}
    private fun text(t:String){val v=TextView(this);v.text=t;v.textSize=15f;v.setTextColor(Color.DKGRAY);v.setPadding(4,dp(6),4,dp(6));content.addView(v)}
    private fun ctext(p:LinearLayout,t:String){val v=TextView(this);v.text=t;v.textSize=14f;v.setTextColor(Color.DKGRAY);v.setPadding(0,dp(3),0,dp(3));p.addView(v)}
    private fun info(t:String,n:String,c:Int){val l=LinearLayout(this);l.orientation=LinearLayout.HORIZONTAL;l.setPadding(dp(10),0,dp(10),0);l.setBackgroundColor(Color.rgb(245,248,252));val a=TextView(this);a.text=t;a.textSize=14f;a.setTextColor(c);val b=TextView(this);b.text=n;b.textSize=20f;b.setTextColor(c);b.gravity=Gravity.RIGHT;l.addView(a,LinearLayout.LayoutParams(0,dp(54),1f));l.addView(b,LinearLayout.LayoutParams(dp(70),dp(54)));content.addView(l,LinearLayout.LayoutParams(-1,dp(60)))}
    private fun home(){setContentView(base("HOME"));text("EDISON SOLAR WORK TRACKER");val ws=db.workers();var p=0;var h=0;for(w in ws)when(db.attendance(w.id,today())?.status){"Present"->p++;"Half Day"->h++};info("👷 WORKERS",ws.size.toString(),blue);info("🟢 PRESENT",p.toString(),green);info("🟡 HALF DAY",h.toString(),orange);info("🔴 ABSENT",(ws.size-p-h).toString(),red);content.addView(button("📅 CALENDAR"){attendance()});content.addView(button("💰 SALARY REPORT"){salary()})}
    private fun workers(){setContentView(base("WORKERS"));text("👷 WORKERS");content.addView(button("➕ ADD WORKER"){workerDialog(null)});for(w in db.workers()){val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.setPadding(dp(10),dp(6),dp(10),dp(6));c.setBackgroundColor(Color.rgb(245,248,252));ctext(c,"👷 ${w.name}");ctext(c,"📞 ${w.phone}");ctext(c,"💰 Payment: ${w.paymentType}  ₹${money(w.salary)}");if(w.role.isNotBlank())ctext(c,"🔧 ${w.role}");val r=LinearLayout(this);r.orientation=LinearLayout.HORIZONTAL;r.addView(button("EDIT"){workerDialog(w)},LinearLayout.LayoutParams(0,dp(42),1f));r.addView(button("ADVANCE"){advanceDialog(w)},LinearLayout.LayoutParams(0,dp(42),1f));r.addView(button("DELETE"){confirmDelete(w)},LinearLayout.LayoutParams(0,dp(42),1f));c.addView(r);content.addView(c,LinearLayout.LayoutParams(-1,-2))}}
    private fun confirmDelete(w:Worker){AlertDialog.Builder(this).setTitle("Delete Worker?").setMessage(w.name).setNegativeButton("CANCEL",null).setPositiveButton("DELETE"){_,_->db.deleteWorker(w.id);workers()}.show()}
    private fun workerDialog(old:Worker?){
        val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(dp(18),0,dp(18),0)
        val n=EditText(this);n.hint="Worker Name";val ph=EditText(this);ph.hint="Phone"
        val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Daily","Monthly"))
        val rate=EditText(this);rate.hint="Payment Amount";rate.inputType=2 or 8192
        val role=EditText(this);role.hint="Work / Role"
        if(old!=null){n.setText(old.name);ph.setText(old.phone);type.setSelection(if(old.paymentType=="Monthly")1 else 0);rate.setText(old.salary.toString());role.setText(old.role)}
        l.addView(n);l.addView(ph);l.addView(type);l.addView(rate);l.addView(role)
        val d=AlertDialog.Builder(this).setTitle(if(old==null)"Add Worker" else "Edit Worker").setView(l).setNegativeButton("CANCEL",null).setPositiveButton(if(old==null)"SAVE" else "UPDATE",null).create()
        d.setOnShowListener{d.getButton(-1).setOnClickListener{if(n.text.toString().trim().isBlank()){n.error="Enter name";return@setOnClickListener};val w=Worker(old?.id?:0,n.text.toString(),ph.text.toString(),rate.text.toString().toDoubleOrNull()?:0.0,type.selectedItem.toString(),role.text.toString());if(old==null)db.addWorker(w) else db.updateWorker(w);d.dismiss();workers()}};d.show()
    }
    private fun attendance(){setContentView(base("CALENDAR"));text("📅 ATTENDANCE CALENDAR");content.addView(button("📅 ${d(selectedDate)}"){pickDate()});refreshAttendance()}
    private fun pickDate(){val c=Calendar.getInstance();try{c.time=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).parse(selectedDate)!!}catch(_:Exception){};DatePickerDialog(this,{_,y,m,day->val x=Calendar.getInstance();x.set(y,m,day);selectedDate=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(x.time);attendance()},c.get(1),c.get(2),c.get(5)).show()}
    private fun refreshAttendance(){val ws=db.workers();var p=0;var h=0;var a=0;val groups=linkedMapOf<String,MutableList<Worker>>();for(w in ws){val r=db.attendance(w.id,selectedDate);when(r?.status){"Present"->p++;"Half Day"->h++;else->a++};val site=if(!r?.site.isNullOrBlank())r!!.site.trim() else "No Site Assigned";groups.getOrPut(site){mutableListOf()}.add(w)};info("🟢 PRESENT",p.toString(),green);info("🟡 HALF DAY",h.toString(),orange);info("🔴 ABSENT",a.toString(),red);info("👷 WORKING",(p+h).toString(),blue);text("📍 SITE SUMMARY");for((site,list) in groups){var sp=0;var sh=0;var sa=0;for(w in list)when(db.attendance(w.id,selectedDate)?.status){"Present"->sp++;"Half Day"->sh++;else->sa++};val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.setPadding(dp(10),dp(6),dp(10),dp(6));c.setBackgroundColor(Color.rgb(245,248,252));ctext(c,"📍 $site");ctext(c,"🟢 $sp   🟡 $sh   🔴 $sa   👷 ${list.size}");c.addView(button("VIEW WORKERS"){siteDialog(site,list)});content.addView(c)};text("👷 WORKER ATTENDANCE");for(w in ws){val s=db.attendance(w.id,selectedDate)?.status?:"Absent";content.addView(button("👷 ${w.name} — $s"){attendanceDialog(w,db.attendance(w.id,selectedDate))})}}
    private fun siteDialog(site:String,list:List<Worker>){val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(dp(10),0,dp(10),0);for(w in list){val s=db.attendance(w.id,selectedDate)?.status?:"Absent";l.addView(button("👷 ${w.name} — $s"){attendanceDialog(w,db.attendance(w.id,selectedDate))})};AlertDialog.Builder(this).setTitle("📍 $site").setView(l).setPositiveButton("CLOSE",null).show()}
    private fun attendanceDialog(w:Worker,old:Att?){
        val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(dp(18),0,dp(18),0)
        val st=Spinner(this);st.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Present","Absent","Half Day"));st.setSelection(arrayOf("Present","Absent","Half Day").indexOf(old?.status?:"Absent").coerceAtLeast(0))
        val it=EditText(this);it.hint="In Time";val ot=EditText(this);ot.hint="Out Time";val site=EditText(this);site.hint="Site";val note=EditText(this);note.hint="Work Note";val la=EditText(this);la.hint="Latitude";val lo=EditText(this);lo.hint="Longitude";la.isEnabled=false;lo.isEnabled=false
        if(old!=null){it.setText(old.inTime);ot.setText(old.outTime);site.setText(old.site);note.setText(old.note);if(old.lat!=0.0)la.setText(old.lat.toString());if(old.lon!=0.0)lo.setText(old.lon.toString())}
        l.addView(st);l.addView(it);l.addView(ot);l.addView(site);l.addView(note);l.addView(la);l.addView(lo);l.addView(button("📍 GET GPS"){getGps(la,lo)});l.addView(button("🗺️ OPEN MAP"){openMap(site.text.toString(),la.text.toString(),lo.text.toString())})
        val d=AlertDialog.Builder(this).setTitle("👷 ${w.name}").setView(l).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create()
        d.setOnShowListener{d.getButton(-1).setOnClickListener{db.saveAttendance(w.id,selectedDate,st.selectedItem.toString(),it.text.toString(),ot.text.toString(),site.text.toString(),note.text.toString(),la.text.toString().toDoubleOrNull()?:0.0,lo.text.toString().toDoubleOrNull()?:0.0);d.dismiss();attendance()}};d.show()
    }
    private fun getGps(la:EditText,lo:EditText){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),LOCATION);return};try{val m=getSystemService(LOCATION_SERVICE) as LocationManager;val p=if(m.isProviderEnabled(LocationManager.GPS_PROVIDER))LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER;val x=m.getLastKnownLocation(p);if(x!=null){la.setText(x.latitude.toString());lo.setText(x.longitude.toString());Toast.makeText(this,"GPS added",Toast.LENGTH_SHORT).show()}else Toast.makeText(this,"Location கிடைக்கவில்லை",Toast.LENGTH_SHORT).show()}catch(_:Exception){Toast.makeText(this,"GPS error",Toast.LENGTH_SHORT).show()}}
    private fun openMap(site:String,la:String,lo:String){val a=la.toDoubleOrNull();val b=lo.toDoubleOrNull();val uri=if(a!=null&&b!=null&&a!=0.0&&b!=0.0)Uri.parse("geo:$a,$b?q=$a,$b") else if(site.isNotBlank())Uri.parse("geo:0,0?q="+Uri.encode(site)) else null;if(uri!=null)try{startActivity(Intent(Intent.ACTION_VIEW,uri))}catch(_:Exception){Toast.makeText(this,"Maps not available",Toast.LENGTH_SHORT).show()}else Toast.makeText(this,"Site/GPS enter pannunga",Toast.LENGTH_SHORT).show()}
    private fun salary(){
        setContentView(base("SALARY"))
        text("💰 SALARY / PENDING REPORT")
        val c=reportMonth
        content.addView(button("📅 REPORT MONTH: ${c.get(Calendar.MONTH)+1}-${c.get(Calendar.YEAR)}"){monthPicker()})
        content.addView(button("📄 ALL WORKERS PDF / WHATSAPP"){makePdfAll()})
        for(w in db.workers()){
            val pair=db.monthCounts(w.id,c.get(Calendar.YEAR),c.get(Calendar.MONTH))
            val days=pair.first+pair.second*0.5
            val earned=if(w.paymentType=="Daily") days*w.salary else w.salary
            val adv=db.advanceTotal(w.id)
            val pending=earned-adv
            val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(dp(10),dp(6),dp(10),dp(6));box.setBackgroundColor(Color.rgb(245,248,252))
            ctext(box,"👷 ${w.name}");ctext(box,"Payment: ${w.paymentType}  Rate: ₹${money(w.salary)}")
            ctext(box,"Present: ${pair.first}  Half: ${pair.second}  Total Days: ${money(days)}")
            ctext(box,"Earned: ₹${money(earned)}  Advance: ₹${money(adv)}")
            ctext(box,"💰 PENDING: ₹${money(pending)}")
            box.addView(button("ADVANCE HISTORY / EDIT"){advanceDialog(w)})
            content.addView(box)
        }
    }
    private fun monthPicker(){DatePickerDialog(this,{_,y,m,_->reportMonth=Calendar.getInstance().apply{set(y,m,1)};salary()},reportMonth.get(Calendar.YEAR),reportMonth.get(Calendar.MONTH),1).show()}
    private fun advanceDialog(w:Worker){
        val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(dp(15),0,dp(15),0)
        for(a in db.advances(w.id)){val row=LinearLayout(this);row.orientation=LinearLayout.HORIZONTAL;val t=TextView(this);t.text="${a.date}  ₹${money(a.amount)}  ${a.note}";t.textSize=13f;row.addView(t,LinearLayout.LayoutParams(0,dp(48),1f));row.addView(button("EDIT"){advanceEdit(w,a)},LinearLayout.LayoutParams(dp(65),dp(44)));row.addView(button("DEL"){db.deleteAdvance(a.id);advanceDialog(w)},LinearLayout.LayoutParams(dp(55),dp(44)));l.addView(row)}
        l.addView(button("➕ ADD ADVANCE"){advanceEdit(w,null)})
        AlertDialog.Builder(this).setTitle("Advance — ${w.name}").setView(l).setPositiveButton("CLOSE",null).show()
    }
    private fun advanceEdit(w:Worker,a:Adv?){
        val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(dp(18),0,dp(18),0)
        val amount=EditText(this);amount.hint="Amount";amount.inputType=2 or 8192;val date=EditText(this);date.hint="Date YYYY-MM-DD";val note=EditText(this);note.hint="Note"
        if(a!=null){amount.setText(a.amount.toString());date.setText(a.date);note.setText(a.note)}else date.setText(today())
        l.addView(amount);l.addView(date);l.addView(note)
        val d=AlertDialog.Builder(this).setTitle(if(a==null)"Add Advance" else "Edit Advance").setView(l).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create()
        d.setOnShowListener{d.getButton(-1).setOnClickListener{db.saveAdvance(Adv(a?.id?:0,w.id,amount.text.toString().toDoubleOrNull()?:0.0,date.text.toString(),note.text.toString()));d.dismiss();salary()}};d.show()
    }
    private fun makePdfAll(){
        val y=reportMonth.get(Calendar.YEAR);val m=reportMonth.get(Calendar.MONTH)
        val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val p=page.canvas;val paint=Paint();paint.textSize=18f;paint.color=Color.rgb(13,71,161);p.drawText("EDISON SOLAR - SALARY REPORT",30f,40f,paint);paint.textSize=11f;paint.color=Color.BLACK;p.drawText("Month: ${m+1}-$y",30f,60f,paint);var yy=90f
        p.drawText("Worker | Type | Days | Earned | Advance | Pending",30f,yy,paint);yy+=22
        for(w in db.workers()){val q=db.monthCounts(w.id,y,m);val days=q.first+q.second*.5;val earned=if(w.paymentType=="Daily")days*w.salary else w.salary;val adv=db.advanceTotal(w.id);p.drawText("${w.name} | ${w.paymentType} | ${money(days)} | ₹${money(earned)} | ₹${money(adv)} | ₹${money(earned-adv)}",30f,yy,paint);yy+=20;if(yy>810)break}
        doc.finishPage(page)
        val name="EDISON_Salary_${m+1}_$y.pdf"
        val resolver=contentResolver
        val values=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS)}
        val uri=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
        if(uri!=null){resolver.openOutputStream(uri)?.use{doc.writeTo(it)};doc.close();sharePdf(uri,name)}else{doc.close();Toast.makeText(this,"PDF create failed",Toast.LENGTH_SHORT).show()}
    }
    private fun sharePdf(uri:Uri,name:String){val send=Intent(Intent.ACTION_SEND);send.type="application/pdf";send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"Send PDF"))}
    private fun money(x:Double)=String.format(Locale.getDefault(),"%.2f",x)
}
