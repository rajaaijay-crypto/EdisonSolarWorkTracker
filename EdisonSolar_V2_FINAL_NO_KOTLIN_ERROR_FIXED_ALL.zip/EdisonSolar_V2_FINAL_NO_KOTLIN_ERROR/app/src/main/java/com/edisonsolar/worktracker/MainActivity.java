package com.edisonsolar.worktracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.Window;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView webView; private ValueCallback<android.net.Uri[]> fileCallback; private static final int VOICE=1001, FILE=1002, LOC=1003;
    @Override public void onCreate(Bundle b){super.onCreate(b);requestWindowFeature(Window.FEATURE_NO_TITLE);webView=new WebView(this);webView.setBackgroundColor(Color.WHITE);webView.getSettings().setJavaScriptEnabled(true);webView.getSettings().setDomStorageEnabled(true);webView.getSettings().setAllowFileAccess(true);webView.getSettings().setAllowContentAccess(true);webView.setWebViewClient(new WebViewClient());webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<android.net.Uri[]> cb,FileChooserParams p){fileCallback=cb;startActivityForResult(p.createIntent(),FILE);return true;}});webView.addJavascriptInterface(new NativeBridge(),"AndroidVoice");webView.addJavascriptInterface(new GPSBridge(),"AndroidGPS");webView.loadUrl("file:///android_asset/index.html");setContentView(webView);}
    class NativeBridge{@JavascriptInterface public void startVoice(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},VOICE);return;}Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN");startActivityForResult(i,VOICE);}}
    class GPSBridge{@JavascriptInterface public void getLocation(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOC);return;}LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);try{Location l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(l==null)l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(l!=null)webView.evaluateJavascript("onGPS("+l.getLatitude()+","+l.getLongitude()+")",null);else lm.requestSingleUpdate(LocationManager.GPS_PROVIDER,new LocationListener(){public void onLocationChanged(Location l){webView.evaluateJavascript("onGPS("+l.getLatitude()+","+l.getLongitude()+")",null);}public void onProviderEnabled(String s){}public void onProviderDisabled(String s){}public void onStatusChanged(String s,int a,Bundle x){}},null);}catch(Exception e){webView.evaluateJavascript("toast('GPS unavailable')",null);}}}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==VOICE&&c==RESULT_OK&&d!=null){ArrayList<String> x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty())webView.evaluateJavascript("processVoice("+org.json.JSONObject.quote(x.get(0))+")",null);}else if(r==FILE){if(fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));fileCallback=null;}}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==VOICE&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)((NativeBridge)new NativeBridge()).startVoice();if(r==LOC&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)((GPSBridge)new GPSBridge()).getLocation();}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
