package com.edisonsolar.worktracker;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.graphics.Color;
public class MainActivity extends Activity{
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.setBackgroundColor(Color.WHITE); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setWebViewClient(new WebViewClient()); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
