EDISON SOLAR APP V2 - FINAL MODEL BUILD

This project uses a WebView-based professional UI so the app screen can closely match the approved 2451.jpg model while remaining Java-only and easy to build.

Screens implemented: Login-ready dashboard, Customers, Leads/Follow-up, Quotation, Invoice/Payment, Installation/Site Survey, Stock, Workers, Reminders, Service, Reports/Graphs, Expenses, Settings/Backup, Side Menu.

Phone: 6383287878
Version: 2.0-FINAL-MODEL
Reference: FINAL_MODEL_2451.jpg
