# EDISON SOLAR App V2

Android site-work tracker starter project, version 2.0.

Included: login screen, dashboard, customer/site entry, GPS capture, camera photo, local site database, site history, kW totals, and Google Maps hand-off.

## Build
1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Let Gradle sync and install Android SDK 35.
3. Run on an Android phone/emulator.
4. Grant Location and Camera permissions when prompted.

Google Maps is opened through the installed Maps app, so no Maps API key is required for this version.

The login is currently local/demo login; production authentication and cloud sync can be added later.
