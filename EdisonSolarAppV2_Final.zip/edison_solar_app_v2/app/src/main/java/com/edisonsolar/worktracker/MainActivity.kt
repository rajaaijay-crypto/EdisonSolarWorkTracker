package com.edisonsolar.worktracker
import android.app.*;import android.os.*;import android.content.*;import android.widget.*
class MainActivity:androidx.appcompat.app.AppCompatActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);findViewById<com.google.android.material.button.MaterialButton>(R.id.login).setOnClickListener{go()};findViewById<com.google.android.material.button.MaterialButton>(R.id.demo).setOnClickListener{go()}}
private fun go(){startActivity(Intent(this,DashboardActivity::class.java));finish()}}
