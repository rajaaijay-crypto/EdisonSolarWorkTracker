package com.edisonsolar.worktracker

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Site(val id: Long, val name: String, val phone: String, val address: String, val kw: Double, val lat: Double?, val lon: Double?, val photo: String?)
class Db(c: Context): SQLiteOpenHelper(c,"edison_solar.db",null,1){
 override fun onCreate(d: SQLiteDatabase){d.execSQL("CREATE TABLE sites(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,kw REAL,lat REAL,lon REAL,photo TEXT,date TEXT)")}
 override fun onUpgrade(d: SQLiteDatabase,o:Int,n:Int){d.execSQL("DROP TABLE sites");onCreate(d)}
 fun add(s:Site){val v=android.content.ContentValues().apply{put("name",s.name);put("phone",s.phone);put("address",s.address);put("kw",s.kw);put("lat",s.lat);put("lon",s.lon);put("photo",s.photo);put("date",java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault()).format(java.util.Date()))};writableDatabase.insert("sites",null,v)}
 fun all():List<Site>{val a=mutableListOf<Site>();readableDatabase.rawQuery("SELECT * FROM sites ORDER BY id DESC",null).use{c->while(c.moveToNext())a.add(Site(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getDouble(4),if(c.isNull(5))null else c.getDouble(5),if(c.isNull(6))null else c.getDouble(6),if(c.isNull(7))null else c.getString(7)))};return a}
 fun one(id:Long):Site?=all().firstOrNull{it.id==id}
}
