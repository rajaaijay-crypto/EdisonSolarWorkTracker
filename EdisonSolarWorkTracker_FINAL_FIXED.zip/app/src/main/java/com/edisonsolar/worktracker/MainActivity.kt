package com.edisonsolar.worktracker

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Job(
    val date: String,
    val company: String,
    val customer: String,
    val area: String,
    val kw: Double,
    val expense: Double,
    val status: String,
    val type: String,
    val lat: String = "",
    val lon: String = "",
    val payment: Double = 0.0,
    val worker: String = "",
    val salary: Double = 0.0
)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val jobs = mutableListOf<Job>()
    private val companies = mutableListOf<String>()
    private val prefs by lazy { getSharedPreferences("data", MODE_PRIVATE) }
    private var lat = ""
    private var lon = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        dashboard()
    }

    private fun load() {
        prefs.getString("companies", "")?.split("\n")?.filter { it.isNotBlank() }?.let {
            companies.addAll(it)
        }
        prefs.getString("jobs", "")?.split("\n")?.filter { it.isNotBlank() }?.forEach { line ->
            val x = line.split("|")
            if (x.size >= 13) {
                jobs.add(
                    Job(
                        date = x[0], company = x[1], customer = x[2], area = x[3],
                        kw = x[4].toDoubleOrNull() ?: 0.0,
                        expense = x[5].toDoubleOrNull() ?: 0.0,
                        status = x[6], type = x[7], lat = x[8], lon = x[9],
                        payment = x[10].toDoubleOrNull() ?: 0.0,
                        worker = x[11], salary = x[12].toDoubleOrNull() ?: 0.0
                    )
                )
            }
        }
    }

    private fun save() {
        val jobText = jobs.joinToString("\n") { j ->
            listOf(j.date, j.company, j.customer, j.area, j.kw, j.expense, j.status, j.type, j.lat, j.lon, j.payment, j.worker, j.salary)
                .joinToString("|")
        }
        prefs.edit()
            .putString("companies", companies.joinToString("\n"))
            .putString("jobs", jobText)
            .apply()
    }

    private fun base(title: String) {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(28, 22, 28, 18)
        val header = TextView(this)
        header.text = title
        header.textSize = 25f
        header.setTextColor(Color.rgb(20, 80, 35))
        root.addView(header)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun btn(text: String, action: () -> Unit) {
        val button = Button(this)
        button.text = text
        button.setOnClickListener { action() }
        root.addView(button)
    }

    private fun field(hint: String, value: String = ""): EditText {
        val edit = EditText(this)
        edit.hint = hint
        edit.setText(value)
        edit.textSize = 17f
        root.addView(edit)
        return edit
    }

    private fun companySpinner(): Spinner {
        if (companies.isEmpty()) companies.add("Company 1")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, companies)
        root.addView(spinner)
        return spinner
    }

    private fun captureLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 10)
            return
        }
        LocationServices.getFusedLocationProviderClient(this).lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location != null) {
                    lat = location.latitude.toString()
                    lon = location.longitude.toString()
                    Toast.makeText(this, "GPS captured", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "GPS location not available", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun dashboard() {
        base("☀️ Edison Solar\nWork Tracker")
        val monthYear = SimpleDateFormat("MM/yyyy", Locale.getDefault()).format(Date())
        val monthJobs = jobs.filter { it.date.endsWith(monthYear) }
        val payment = monthJobs.sumOf { it.payment }
        val expense = monthJobs.sumOf { it.expense }
        val salary = monthJobs.sumOf { it.salary }
        val profit = payment - expense - salary
        val text = TextView(this)
        text.textSize = 19f
        text.text = "📅 " + SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date()) +
            "\n\n☀️ Installed: %.2f kW\n💵 Customer Payments: ₹%.2f\n💰 Expenses: ₹%.2f\n👷 Site Salary/Labour: ₹%.2f\n📈 NET PROFIT: ₹%.2f\n🏢 Companies: %d"
                .format(monthJobs.sumOf { it.kw }, payment, expense, salary, profit, companies.size)
        root.addView(text)
        btn("🏢 Manage Companies") { manageCompanies() }
        btn("➕ Add Installation") { installation() }
        btn("💰 Add Expense") { expenseEntry() }
        btn("👷 Add Site Salary / Labour") { salaryEntry() }
        btn("📍 Capture Current GPS") { captureLocation() }
        btn("📊 Monthly Report") { report() }
        btn("🏢 Company-wise Reports") { companyReports() }
        btn("📋 All History") { history() }
        btn("📤 Export CSV Report") { exportCsv() }
    }

    private fun manageCompanies() {
        base("🏢 Companies")
        val name = field("New company name")
        btn("ADD COMPANY") {
            val value = name.text.toString().trim()
            if (value.isNotEmpty()) {
                companies.add(value)
                save()
                manageCompanies()
            }
        }
        companies.forEach { company ->
            btn("📁 $company") { companyReport(company) }
        }
        btn("← Dashboard") { dashboard() }
    }

    private fun installation() {
        base("➕ Installation")
        val date = field("Date DD/MM/YYYY", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
        val spinner = companySpinner()
        val customer = field("Customer")
        val area = field("Area / Site")
        val kw = field("Installed kW")
        val payment = field("Customer Payment ₹")
        val status = field("Status", "Completed")
        btn("📍 CAPTURE SITE GPS") { captureLocation() }
        btn("SAVE INSTALLATION") {
            jobs.add(
                Job(date.text.toString(), spinner.selectedItem.toString(), customer.text.toString(), area.text.toString(),
                    kw.text.toString().toDoubleOrNull() ?: 0.0, 0.0, status.text.toString(), "INSTALL", lat, lon,
                    payment.text.toString().toDoubleOrNull() ?: 0.0)
            )
            save()
            dashboard()
        }
        btn("← Back") { dashboard() }
    }

    private fun expenseEntry() {
        base("💰 Expense")
        val date = field("Date DD/MM/YYYY", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
        val spinner = companySpinner()
        val area = field("Site / Area")
        val amount = field("Amount ₹")
        val type = field("Travel / Food / Material / Other", "Travel")
        btn("SAVE EXPENSE") {
            jobs.add(Job(date.text.toString(), spinner.selectedItem.toString(), "Expense", area.text.toString(), 0.0,
                amount.text.toString().toDoubleOrNull() ?: 0.0, type.text.toString(), "EXPENSE", lat, lon))
            save()
            dashboard()
        }
        btn("← Back") { dashboard() }
    }

    private fun salaryEntry() {
        base("👷 Site Salary / Labour")
        val date = field("Date DD/MM/YYYY", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
        val spinner = companySpinner()
        val area = field("Site / Area")
        val worker = field("Worker name")
        val amount = field("Salary ₹")
        btn("SAVE SALARY") {
            jobs.add(Job(date.text.toString(), spinner.selectedItem.toString(), worker.text.toString(), area.text.toString(), 0.0, 0.0,
                "Paid", "SALARY", lat, lon, 0.0, worker.text.toString(), amount.text.toString().toDoubleOrNull() ?: 0.0))
            save()
            dashboard()
        }
        btn("← Back") { dashboard() }
    }

    private fun report() {
        base("📊 Monthly Profit Report")
        val monthYear = SimpleDateFormat("MM/yyyy", Locale.getDefault()).format(Date())
        val monthJobs = jobs.filter { it.date.endsWith(monthYear) }
        val payment = monthJobs.sumOf { it.payment }
        val expense = monthJobs.sumOf { it.expense }
        val salary = monthJobs.sumOf { it.salary }
        val text = TextView(this)
        text.textSize = 17f
        val companyLines = companies.joinToString("\n") { company ->
            val q = monthJobs.filter { it.company == company }
            val p = q.sumOf { it.payment }
            val e = q.sumOf { it.expense }
            val s = q.sumOf { it.salary }
            "$company → %.2f kW | Payment ₹%.2f | Expense ₹%.2f | Salary ₹%.2f | PROFIT ₹%.2f".format(q.sumOf { it.kw }, p, e, s, p - e - s)
        }
        text.text = "Month: $monthYear\n\n☀️ Installed: %.2f kW\n💵 Customer Payments: ₹%.2f\n💰 Other Expenses: ₹%.2f\n👷 Site Salary/Labour: ₹%.2f\n📈 NET PROFIT: ₹%.2f\n\n🏢 COMPANY-WISE PROFIT\n%s"
            .format(monthJobs.sumOf { it.kw }, payment, expense, salary, payment - expense - salary, companyLines)
        root.addView(text)
        btn("← Dashboard") { dashboard() }
    }

    private fun companyReports() {
        base("🏢 Select Company")
        companies.forEach { company -> btn("📁 $company") { companyReport(company) } }
        btn("← Dashboard") { dashboard() }
    }

    private fun companyReport(company: String) {
        base("🏢 $company Report")
        val all = jobs.filter { it.company == company }
        val payment = all.sumOf { it.payment }
        val expense = all.sumOf { it.expense }
        val salary = all.sumOf { it.salary }
        val workers = all.filter { it.type == "SALARY" }.joinToString("\n") { j ->
            "${j.date} • ${j.worker} • ${j.area} • ₹${j.salary}"
        }
        val text = TextView(this)
        text.textSize = 17f
        text.text = "Company: $company\n\n☀️ Total Installed: %.2f kW\n💵 Total Payments: ₹%.2f\n💰 Total Expenses: ₹%.2f\n👷 Total Salary/Labour: ₹%.2f\n📈 NET PROFIT: ₹%.2f\n🏠 Installation Jobs: %d\n\nWorker Salary Details:\n%s"
            .format(all.sumOf { it.kw }, payment, expense, salary, payment - expense - salary, all.count { it.type == "INSTALL" }, workers)
        root.addView(text)
        btn("← Companies") { companyReports() }
    }

    private fun history() {
        base("📋 All History")
        val text = TextView(this)
        text.textSize = 16f
        text.text = if (jobs.isEmpty()) {
            "No entries yet."
        } else {
            jobs.joinToString("\n\n") { job ->
                when (job.type) {
                    "SALARY" -> "📅 ${job.date}\n🏢 ${job.company}\n📍 ${job.area}\n👷 ${job.worker}\n💵 Salary ₹${job.salary}"
                    "EXPENSE" -> "📅 ${job.date}\n🏢 ${job.company}\n📍 ${job.area}\n💰 ${job.status}: ₹${job.expense}"
                    else -> "📅 ${job.date}\n🏢 ${job.company}\n📍 ${job.area}\n👤 ${job.customer}\n☀️ ${job.kw} kW\n💵 Payment ₹${job.payment}\n📝 ${job.status}"
                }
            }
        }
        root.addView(text)
        btn("← Dashboard") { dashboard() }
    }

    private fun exportCsv() {
        val file: File = File(getExternalFilesDir(null), "edison_solar_report.csv")
        file.writeText(buildString {
            append("Date,Company,Customer,Area,kW,Expense,Status,Type,Latitude,Longitude,Payment,Worker,Salary\n")
            jobs.forEach { job ->
                val values = listOf(job.date, job.company, job.customer, job.area, job.kw, job.expense, job.status, job.type, job.lat, job.lon, job.payment, job.worker, job.salary)
                append(values.joinToString(",") { value -> "\"${value.toString().replace("\"", "\"\"")}\"" })
                append("\n")
            }
        })
        Toast.makeText(this, "CSV saved: ${file.name}", Toast.LENGTH_LONG).show()
    }
}
