package com.edisonsolar.worktracker

import android.app.*
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.widget.*
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import java.text.SimpleDateFormat
import java.util.*

data class Job(val date:String,val company:String,val customer:String,val area:String,val kw:Double,val expense:Double,val status:String,val type:String,val lat:String="",val lon:String="",val payment:Double=0.0,val worker:String="",val salary:Double=0.0)

class MainActivity:Activity(){
 private lateinit var root:LinearLayout
 private val jobs=mutableListOf<Job>()
 private val companies=mutableListOf<String>()
 private val prefs by lazy{getSharedPreferences("data",MODE_PRIVATE)}
 private var lat=""; private var lon=""
 override fun onCreate(b:Bundle?){super.onCreate(b);load();dashboard()}
 private fun load(){
  prefs.getString("companies","")?.split("\n")?.filter{it.isNotBlank()}?.let{companies.addAll(it)}
  prefs.getString("jobs","")?.split("\n")?.filter{it.isNotBlank()}?.forEach{p->
   val x=p.split("|"); if(x.size>=15) jobs.add(Job(x[0],x[1],x[2],x[3],x[4].toDoubleOrNull()?:0.0,x[5].toDoubleOrNull()?:0.0,x[6],x[7],x[8],x[9],x[10].toDoubleOrNull()?:0.0,x[11],x[12].toDoubleOrNull()?:0.0))
  }
 }
 private fun save(){prefs.edit().putString("companies",companies.joinToString("\n")).putString("jobs",jobs.joinToString("\n"){"${it.date}|${it.company}|${it.customer}|${it.area}|${it.kw}|${it.expense}|${it.status}|${it.type}|${it.lat}|${it.lon}|${it.payment}|${it.worker}|${it.salary}||"}).apply()}
 private fun base(title:String){root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(28,22,28,18);val h=TextView(this);h.text=title;h.textSize=25f;h.setTextColor(Color.rgb(20,80,35));root.addView(h);val s=ScrollView(this);s.addView(root);setContentView(s)}
 private fun btn(t:String,a:()->Unit){Button(this).also{it.text=t;it.setOnClickListener{a()};root.addView(it)}}
 private fun field(h:String,v:String=""):EditText=EditText(this).also{it.hint=h;it.setText(v);it.textSize=17f;root.addView(it)}
 private fun spinner():Spinner=Spinner(this).also{s;if(companies.isEmpty())companies.add("Company 1");s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,companies);root.addView(s)}
 private fun location(){if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),10);return};LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener{l:Location?->if(l!=null){lat=l.latitude.toString();lon=l.longitude.toString();Toast.makeText(this,"GPS captured",Toast.LENGTH_SHORT).show()}}}
 private fun dashboard(){
  base("☀️ Edison Solar\nWork Tracker");val ym=SimpleDateFormat("MM/yyyy",Locale.getDefault()).format(Date());val m=jobs.filter{it.date.endsWith(ym)}
  val payment=m.sumOf{it.payment};val expense=m.sumOf{it.expense};val salary=m.sumOf{it.salary};val profit=payment-expense-salary
  val t=TextView(this);t.text="📅 "+SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date())+"\n\n☀️ Installed: %.2f kW\n💵 Customer Payments: ₹%.2f\n💰 Expenses: ₹%.2f\n👷 Site Salary/Labour: ₹%.2f\n📈 NET PROFIT: ₹%.2f\n🏢 Companies: %d".format(m.sumOf{it.kw},payment,expense,salary,profit,companies.size);t.textSize=19f;root.addView(t)
  btn("🏢 Manage Companies"){manageCompanies()};btn("➕ Add Installation"){entry()};btn("💰 Add Expense"){expense()};btn("👷 Add Site Salary / Labour"){salary()};btn("📍 Capture Current GPS"){location()};btn("📊 Monthly Report"){report()};btn("🏢 Company-wise Reports"){companyReports()};btn("📋 All History"){history()};btn("📤 Export CSV Report"){exportCsv()}
 }
 private fun manageCompanies(){base("🏢 Companies");val n=field("New company name");btn("ADD COMPANY"){if(n.text.toString().trim().isNotEmpty()){companies.add(n.text.toString().trim());save();manageCompanies()}};companies.forEach{c->btn("📁 $c"){companyReport(c)}};btn("← Dashboard"){dashboard()}}
 private fun entry(){base("➕ Installation");val d=field("Date DD/MM/YYYY",SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date()));val sp=spinner();val cu=field("Customer");val ar=field("Area / Site");val kw=field("Installed kW");val pay=field("Customer Payment ₹");val st=field("Status","Completed");btn("📍 CAPTURE SITE GPS"){location()};btn("SAVE INSTALLATION"){jobs.add(Job(d.text.toString(),sp.selectedItem.toString(),cu.text.toString(),ar.text.toString(),kw.text.toString().toDoubleOrNull()?:0.0,0.0,st.text.toString(),"INSTALL",lat,lon,pay.text.toString().toDoubleOrNull()?:0.0));save();dashboard()};btn("← Back"){dashboard()}}
 private fun expense(){base("💰 Expense");val d=field("Date DD/MM/YYYY",SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date()));val sp=spinner();val ar=field("Site / Area");val a=field("Amount ₹");val ty=field("Travel / Food / Material / Other","Travel");btn("SAVE EXPENSE"){jobs.add(Job(d.text.toString(),sp.selectedItem.toString(),"Expense",ar.text.toString(),0.0,a.text.toString().toDoubleOrNull()?:0.0,ty.text.toString(),"EXPENSE",lat,lon));save();dashboard()};btn("← Back"){dashboard()}}
 private fun salary(){base("👷 Site Salary / Labour");val d=field("Date DD/MM/YYYY",SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date()));val sp=spinner();val ar=field("Site / Area");val w=field("Worker name");val a=field("Salary ₹");btn("SAVE SALARY"){jobs.add(Job(d.text.toString(),sp.selectedItem.toString(),w.text.toString(),ar.text.toString(),0.0,0.0,"Paid","SALARY",lat,lon,0.0,w.text.toString(),a.text.toString().toDoubleOrNull()?:0.0));save();dashboard()};btn("← Back"){dashboard()}}
 private fun report(){base("📊 Monthly Profit Report");val ym=SimpleDateFormat("MM/yyyy",Locale.getDefault()).format(Date());val m=jobs.filter{it.date.endsWith(ym)};val pay=m.sumOf{it.payment};val exp=m.sumOf{it.expense};val sal=m.sumOf{it.salary};val t=TextView(this);t.textSize=17f;t.text="Month: $ym\n\n☀️ Installed: %.2f kW\n💵 Customer Payments: ₹%.2f\n💰 Other Expenses: ₹%.2f\n👷 Site Salary/Labour: ₹%.2f\n📈 NET PROFIT: ₹%.2f\n\n🏢 COMPANY-WISE PROFIT\n%s".format(m.sumOf{it.kw},pay,exp,sal,pay-exp-sal,companies.joinToString("\n"){c->val q=m.filter{it.company==c};val p=q.sumOf{it.payment};val e=q.sumOf{it.expense};val s=q.sumOf{it.salary};"$c → %.2f kW | Payment ₹%.2f | Expense ₹%.2f | Salary ₹%.2f | PROFIT ₹%.2f".format(q.sumOf{it.kw},p,e,s,p-e-s)});root.addView(t);btn("← Dashboard"){dashboard()}}
 private fun companyReports(){base("🏢 Select Company");companies.forEach{c->btn("📁 $c"){companyReport(c)}};btn("← Dashboard"){dashboard()}}
 private fun companyReport(c:String){base("🏢 $c Report");val all=jobs.filter{it.company==c};val pay=all.sumOf{it.payment};val exp=all.sumOf{it.expense};val sal=all.sumOf{it.salary};val t=TextView(this);t.textSize=17f;t.text="Company: $c\n\n☀️ Total Installed: %.2f kW\n💵 Total Payments: ₹%.2f\n💰 Total Expenses: ₹%.2f\n👷 Total Salary/Labour: ₹%.2f\n📈 NET PROFIT: ₹%.2f\n🏠 Installation Jobs: %d\n\nWorker Salary Details:\n%s".format(all.sumOf{it.kw},pay,exp,sal,pay-exp-sal,all.count{it.type=="INSTALL"},all.filter{it.type=="SALARY"}.joinToString("\n"){"${it.date} • ${it.worker} • ${it.area} • ₹${it.salary}"});root.addView(t);btn("← Companies"){companyReports()}}
 private fun history(){base("📋 All History");val t=TextView(this);t.textSize=16f;t.text=if(jobs.isEmpty())"No entries yet." else jobs.joinToString("\n\n"){when(it.type){"SALARY"->"📅 ${it.date}\n🏢 ${it.company}\n📍 ${it.area}\n👷 ${it.worker}\n💵 Salary ₹${it.salary}";"EXPENSE"->"📅 ${it.date}\n🏢 ${it.company}\n📍 ${it.area}\n💰 ${it.status}: ₹${it.expense}";else->"📅 ${it.date}\n🏢 ${it.company}\n📍 ${it.area}\n👤 ${it.customer}\n☀️ ${it.kw} kW\n💵 Payment ₹${it.payment}\n📝 ${it.status}"}};root.addView(t);btn("← Dashboard"){dashboard()}}
 private fun exportCsv(){val f=java.io.File(getExternalFilesDir(null),"edison_solar_report.csv");f.writeText(buildString{append("Date,Company,Customer,Area,kW,Expense,Status,Type,Latitude,Longitude,Payment,Worker,Salary\n");jobs.forEach{append(listOf(it.date,it.company,it.customer,it.area,it.kw,it.expense,it.status,it.type,it.lat,it.lon,it.payment,it.worker,it.salary).joinToString(","){"\"${it.toString().replace("\"","\"\"")}\""}).append("\n")}});Toast.makeText(this,"CSV saved: ${f.name}",Toast.LENGTH_LONG).show()}
}