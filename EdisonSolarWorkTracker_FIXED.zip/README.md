# Edison Solar – Work Tracker v1.3

Added in v1.3:
- Worker / site salary and labour entries
- Worker name, date, company, site and salary amount
- Salary/labour is automatically deducted from profit
- Monthly NET PROFIT = Customer Payments - Other Expenses - Salary/Labour
- Company-wise NET PROFIT
- Salary details in company reports
- CSV export includes worker and salary columns
- Existing company, GPS, payment, installation, expense and offline features retained

Build in Android Studio: Build > Build APK(s).
