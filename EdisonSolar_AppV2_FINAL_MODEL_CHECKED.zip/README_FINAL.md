# EDISON SOLAR – App V2 FINAL MODEL

This package uses the user's approved `2451.jpg` as the FINAL UI/model reference.

## Final model screens
1. Splash / Login
2. Professional Dashboard
3. Graph Dashboard
4. Customers
5. New Site / Installation
6. Quotation
7. Invoice
8. Payments
9. Stock
10. Workers
11. Reminders
12. Service
13. Reports
14. Settings / Backup
15. Side Menu

## Included functional areas
- Customer and site records
- Installation entries with kW, payment, expense and labour
- Company management and company reports
- Workers and stock
- Reminders and service records
- Voice entry / voice commands
- GPS capture and map opening
- Site photo capture
- Quotation / invoice PDF sharing
- CSV export
- Reports and charts
- Local backup/export and two-admin design placeholder

## Branding
EDISON SOLAR
Phone: 6383287878

`FINAL_APP_MODEL_REFERENCE.jpg` is included only as the UI reference and must not be treated as an editable app screen.
