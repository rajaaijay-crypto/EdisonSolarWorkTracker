# EDISON SOLAR Professional V2

Android solar business management app prototype, designed around the approved light-blue/white mockup.

Included modules: dashboard, site installation, customers, companies, GPS/Maps, camera photos, voice entry, quotations, invoices, reports, expenses, workers, stock, reminders, service history, search, CSV export and PDF sharing.

This build stores data locally on the phone. Two-admin cloud synchronization requires connecting a Firebase/Supabase project with the owner's credentials; the app does not include shared credentials.

Build with GitHub Actions using the workflow in `.github/workflows/build-apk.yml`.
