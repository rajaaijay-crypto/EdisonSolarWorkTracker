plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.edisonsolar.worktracker"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.edisonsolar.worktracker"
        minSdk = 24
        targetSdk = 35
        versionCode = 20
        versionName = "2.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
