package com.edisonsolar.worktracker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.google.android.gms.location.LocationServices
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

private data class Job(var date:String,var company:String,var customer:String,var site:String,var kw:Double,var payment:Double,var expense:Double,var salary:Double,var type:String="Installation",var lat:String="",var lon:String="",var notes:String="",var photoPath:String="")
private data class Customer(var name:String,var phone:String,var address:String,var company:String,var kw:Double,var paid:Double,var pending:Double,var lat:String="",var lon:String="",var photoPath:String="")
private data class Company(var name:String)
private data class Worker(var name:String,var days:Int,var salary:Double,var advance:Double)
private data class Stock(var name:String,var qty:Double,var unit:String)
private data class Reminder(var title:String,var date:String,var amount:Double)
private data class Service(var customer:String,var date:String,var note:String)

class MainActivity : Activity() {
    private val blue = Color.rgb(25,118,210); private val pale = Color.rgb(235,247,255); private val dark = Color.rgb(25,55,85); private val green=Color.rgb(34,139,84); private val orange=Color.rgb(245,143,35)
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("edison_v2", MODE_PRIVATE) }
    private val jobs=mutableListOf<Job>(); private val customers=mutableListOf<Customer>(); private val companies=mutableListOf<Company>(); private val workers=mutableListOf<Worker>(); private val stocks=mutableListOf<Stock>(); private val reminders=mutableListOf<Reminder>(); private val services=mutableListOf<Service>()
    private var lat=""; private var lon=""; private var photoPath=""; private var voiceRequest=500

    override fun onCreate(b:Bundle?) { super.onCreate(b); load(); dashboard() }

    private fun now():String=SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date())
    private fun month():String=SimpleDateFormat("MM/yyyy",Locale.getDefault()).format(Date())
    private fun enc(s:String)=android.util.Base64.encodeToString(s.toByteArray(),android.util.Base64.NO_WRAP)
    private fun dec(s:String)=runCatching{String(android.util.Base64.decode(s,android.util.Base64.NO_WRAP))}.getOrDefault("")
    private fun pack(parts:List<String>)=parts.joinToString("^"){enc(it)}
    private fun unpack(s:String)=s.split("^").map{dec(it)}
    private fun save(){
        prefs.edit()
            .putString("jobs",jobs.joinToString("\n"){pack(listOf(it.date,it.company,it.customer,it.site,it.kw.toString(),it.payment.toString(),it.expense.toString(),it.salary.toString(),it.type,it.lat,it.lon,it.notes,it.photoPath))})
            .putString("customers",customers.joinToString("\n"){pack(listOf(it.name,it.phone,it.address,it.company,it.kw.toString(),it.paid.toString(),it.pending.toString(),it.lat,it.lon,it.photoPath))})
            .putString("companies",companies.joinToString("\n"){enc(it.name)})
            .putString("workers",workers.joinToString("\n"){pack(listOf(it.name,it.days.toString(),it.salary.toString(),it.advance.toString()))})
            .putString("stocks",stocks.joinToString("\n"){pack(listOf(it.name,it.qty.toString(),it.unit))})
            .putString("reminders",reminders.joinToString("\n"){pack(listOf(it.title,it.date,it.amount.toString()))})
            .putString("services",services.joinToString("\n"){pack(listOf(it.customer,it.date,it.note))}).apply()
    }
    private fun load(){
        fun lines(k:String)=prefs.getString(k,"")!!.split("\n").filter{it.isNotBlank()}
        lines("companies").forEach{companies.add(Company(dec(it)))}
        lines("jobs").forEach{val x=unpack(it);if(x.size>=13)jobs.add(Job(x[0],x[1],x[2],x[3],x[4].toDoubleOrNull()?:0.0,x[5].toDoubleOrNull()?:0.0,x[6].toDoubleOrNull()?:0.0,x[7].toDoubleOrNull()?:0.0,x[8],x[9],x[10],x[11],x[12]))}
        lines("customers").forEach{val x=unpack(it);if(x.size>=10)customers.add(Customer(x[0],x[1],x[2],x[3],x[4].toDoubleOrNull()?:0.0,x[5].toDoubleOrNull()?:0.0,x[6].toDoubleOrNull()?:0.0,x[7],x[8],x[9]))}
        lines("workers").forEach{val x=unpack(it);if(x.size>=4)workers.add(Worker(x[0],x[1].toIntOrNull()?:0,x[2].toDoubleOrNull()?:0.0,x[3].toDoubleOrNull()?:0.0))}
        lines("stocks").forEach{val x=unpack(it);if(x.size>=3)stocks.add(Stock(x[0],x[1].toDoubleOrNull()?:0.0,x[2]))}
        lines("reminders").forEach{val x=unpack(it);if(x.size>=3)reminders.add(Reminder(x[0],x[1],x[2].toDoubleOrNull()?:0.0))}
        lines("services").forEach{val x=unpack(it);if(x.size>=3)services.add(Service(x[0],x[1],x[2]))}
        if(companies.isEmpty()) companies.addAll(listOf(Company("Company 1"),Company("Company 2")))
    }

    private fun setup(title:String, back:(()->Unit)?=null){
        root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(Color.WHITE)
        val bar=LinearLayout(this);bar.setPadding(18,10,12,8);bar.gravity=Gravity.CENTER_VERTICAL;bar.setBackgroundColor(pale)
        if(back!=null){val b=Button(this);b.text="‹";b.textSize=28f;b.setTextColor(blue);b.setBackgroundColor(Color.TRANSPARENT);b.setOnClickListener{back()};bar.addView(b,LinearLayout.LayoutParams(55,58))}
        val t=TextView(this);t.text=title;t.textSize=22f;t.setTypeface(null,Typeface.BOLD);t.setTextColor(dark);bar.addView(t,LinearLayout.LayoutParams(0,58,1f))
        val logo=ImageView(this);logo.setImageResource(com.edisonsolar.worktracker.R.drawable.edison_logo);logo.scaleType=ImageView.ScaleType.CENTER_INSIDE;bar.addView(logo,LinearLayout.LayoutParams(55,58));root.addView(bar)
        val scroll=ScrollView(this);val content=LinearLayout(this);content.orientation=LinearLayout.VERTICAL;content.setPadding(16,14,16,90);scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
        this.content=content
    }
    private lateinit var content:LinearLayout
    private fun tv(s:String,size:Float=16f,bold:Boolean=false):TextView{val v=TextView(this);v.text=s;v.textSize=size;v.setTextColor(dark);if(bold)v.setTypeface(null,Typeface.BOLD);v.setPadding(4,6,4,6);content.addView(v);return v}
    private fun edit(h:String,v:String=""):EditText{val e=EditText(this);e.hint=h;e.setText(v);e.textSize=16f;e.setPadding(12,4,12,4);content.addView(e,LinearLayout.LayoutParams(-1,58));return e}
    private fun button(s:String,action:()->Unit,primary:Boolean=true){val b=Button(this);b.text=s;b.isAllCaps=false;b.textSize=15f;b.setOnClickListener{action()};if(primary){b.setTextColor(Color.WHITE);b.setBackgroundColor(blue)}else b.setTextColor(blue);val p=LinearLayout.LayoutParams(-1,52);p.setMargins(0,6,0,6);content.addView(b,p)}
    private fun card(title:String,value:String,accent:Int=blue){val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(16,12,16,12);box.background=round(Color.WHITE,accent,2,18);val a=TextView(this);a.text=title;a.textSize=13f;a.setTextColor(Color.DKGRAY);val b=TextView(this);b.text=value;b.textSize=22f;b.setTypeface(null,Typeface.BOLD);b.setTextColor(dark);box.addView(a);box.addView(b);val p=LinearLayout.LayoutParams(-1,88);p.setMargins(0,5,0,5);content.addView(box,p)}
    private fun round(fill:Int,stroke:Int,w:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply{setColor(fill);setStroke(w,stroke);cornerRadius=r.toFloat()}
    private fun money(x:Double)="₹"+String.format(Locale.getDefault(),"%,.0f",x)

    private fun dashboard(){
        setup("Dashboard")
        val today=jobs.filter{it.date==now()};val m=jobs.filter{it.date.endsWith(month())};val col=today.sumOf{it.payment};val exp=today.sumOf{it.expense};val sal=today.sumOf{it.salary};val profit=col-exp-sal
        val logo=ImageView(this);logo.setImageResource(R.drawable.edison_logo);logo.adjustViewBounds=true;content.addView(logo,LinearLayout.LayoutParams(-1,145))
        tv("EDISON SOLAR • Professional V2",18f,true);tv("6383287878",15f)
        card("Current Balance",money(jobs.sumOf{it.payment}-jobs.sumOf{it.expense}-jobs.sumOf{it.salary}),green)
        card("Today Profit",money(profit),green);card("Today Collection",money(col),blue);card("Today Expenses",money(exp+sal),orange);card("Installed Today",String.format(Locale.getDefault(),"%.2f kW",today.sumOf{it.kw}),blue)
        tv("This Month",18f,true);tv("Collection ${money(m.sumOf{it.payment})}   •   Expense ${money(m.sumOf{it.expense}+m.sumOf{it.salary})}   •   Profit ${money(m.sumOf{it.payment}-m.sumOf{it.expense}-m.sumOf{it.salary})}")
        button("＋ New Site Entry"){installation()};button("👥 Customers & Sites"){customersScreen()};button("💰 Quotation / Invoice"){billingMenu()};button("📊 Reports & Charts"){reports()};button("🏢 Companies"){companiesScreen()};button("📦 Material Stock"){stockScreen()};button("👷 Worker Management"){workerScreen()};button("🔔 Reminders"){remindersScreen()};button("🔧 Service & Maintenance"){serviceScreen()};button("🎙️ Voice Entry"){voiceEntry()};button("📜 Site / Date History"){history()};button("📤 Excel / CSV Export"){exportCsv()};button("⚙️ Admin & Backup"){adminScreen()}
    }

    private fun companiesScreen(){setup("Companies",::dashboard);companies.forEachIndexed{idx,c->card("Company ${idx+1}",c.name);button("Open Report: ${c.name}"){companyReport(c.name)},false};val e=edit("Add company name");button("＋ Add Company"){if(e.text.isNotBlank()){companies.add(Company(e.text.toString().trim()));save();companiesScreen()}}}
    private fun companyReport(name:String){setup("Company Report",::companiesScreen);val x=jobs.filter{it.company==name};card("Installed kW",String.format(Locale.getDefault(),"%.2f",x.sumOf{it.kw}));card("Collection",money(x.sumOf{it.payment}));card("Expense + Salary",money(x.sumOf{it.expense+it.salary}),orange);card("Net Profit",money(x.sumOf{it.payment-it.expense-it.salary}),green);x.takeLast(20).reversed().forEach{tv("${it.date} • ${it.customer} • ${it.kw} kW • ${money(it.payment-it.expense-it.salary)}")}}

    private fun installation(){setup("New Site Entry",::dashboard);val d=edit("Date",now());val co=edit("Company",companies.firstOrNull()?.name?:("Company 1"));val cu=edit("Customer name");val site=edit("Area / Site");val kw=edit("Installed kW");val pay=edit("Customer payment ₹");val ex=edit("Travel/Food/Material/Other expense ₹");val sal=edit("Site salary/labour ₹");val note=edit("Notes / remarks");button("📍 Capture Current GPS"){captureLocation()};button("📸 Take Site Photo"){takePhoto()};button("🎙️ Fill by Voice"){voiceRequest=501;startVoice()};button("Save Installation"){jobs.add(Job(d.text.toString(),co.text.toString(),cu.text.toString(),site.text.toString(),kw.text.toString().toDoubleOrNull()?:0.0,pay.text.toString().toDoubleOrNull()?:0.0,ex.text.toString().toDoubleOrNull()?:0.0,sal.text.toString().toDoubleOrNull()?:0.0,"Installation",lat,lon,note.text.toString(),photoPath));if(cu.text.isNotBlank())customers.add(Customer(cu.text.toString(),"",site.text.toString(),co.text.toString(),kw.text.toString().toDoubleOrNull()?:0.0,pay.text.toString().toDoubleOrNull()?:0.0,0.0,lat,lon,photoPath));save();Toast.makeText(this,"Site saved successfully",Toast.LENGTH_SHORT).show();dashboard()}}

    private fun customersScreen(){setup("Customers",::dashboard);val q=edit("Search customer / mobile / site");button("Search"){customersScreenFiltered(q.text.toString())};customers.take(50).reversed().forEach{c->val v=TextView(this);v.text="${c.name}\n${c.phone} • ${c.address}\n${c.kw} kW • Paid ${money(c.paid)} • Pending ${money(c.pending)}";v.textSize=16f;v.setPadding(16,12,16,12);v.background=round(Color.WHITE,blue,1,14);v.setOnClickListener{customerDetail(c)};content.addView(v,LinearLayout.LayoutParams(-1,92).apply{setMargins(0,6,0,6)})};button("＋ Add Customer"){addCustomer()}}
    private fun customersScreenFiltered(s:String){if(s.isBlank()){customersScreen();return};setup("Search Results",::customersScreen);customers.filter{it.name.contains(s,true)||it.phone.contains(s)||it.address.contains(s,true)}.forEach{customerDetailCard(it)}}
    private fun customerDetailCard(c:Customer){val b=Button(this);b.text="${c.name} • ${c.kw} kW • Pending ${money(c.pending)}";b.setOnClickListener{customerDetail(c)};content.addView(b)}
    private fun addCustomer(){setup("Add Customer",::customersScreen);val n=edit("Customer name");val p=edit("Mobile");val a=edit("Address / Area");val co=edit("Company");val kw=edit("Installation kW");val paid=edit("Payment received ₹");button("📍 Capture GPS"){captureLocation()};button("📸 Customer Photo"){takePhoto()};button("Save Customer"){customers.add(Customer(n.text.toString(),p.text.toString(),a.text.toString(),co.text.toString(),kw.text.toString().toDoubleOrNull()?:0.0,paid.text.toString().toDoubleOrNull()?:0.0,0.0,lat,lon,photoPath));save();customersScreen()}}
    private fun customerDetail(c:Customer){setup("Customer Details",::customersScreen);tv("${c.name}\n${c.phone}\n${c.address}\n${c.company}\nSystem: ${c.kw} kW\nPaid: ${money(c.paid)}\nPending: ${money(c.pending)}",18f,true);if(c.lat.isNotBlank())button("📍 View Location"){openMap(c.lat,c.lon)};val hist=jobs.filter{it.customer.equals(c.name,true)};tv("Installation history",18f,true);hist.forEach{tv("${it.date} • ${it.kw} kW • ${money(it.payment)} • Profit ${money(it.payment-it.expense-it.salary)}")};button("✏️ Edit Customer"){editCustomer(c)}}
    private fun editCustomer(c:Customer){setup("Edit Customer",::customersScreen);val n=edit("Customer name",c.name);val p=edit("Mobile",c.phone);val a=edit("Address",c.address);val co=edit("Company",c.company);val kw=edit("kW",c.kw.toString());val paid=edit("Paid",c.paid.toString());val pend=edit("Pending",c.pending.toString());button("Update Customer"){c.name=n.text.toString();c.phone=p.text.toString();c.address=a.text.toString();c.company=co.text.toString();c.kw=kw.text.toString().toDoubleOrNull()?:c.kw;c.paid=paid.text.toString().toDoubleOrNull()?:c.paid;c.pending=pend.text.toString().toDoubleOrNull()?:c.pending;save();customersScreen()};button("🗑️ Delete Customer",{customers.remove(c);save();customersScreen()},false)}

    private fun billingMenu(){setup("Quotation & Billing",::dashboard);tv("Business flow: Quotation → Advance → Installation → Invoice → Payment → Pending → Reminder",16f,true);button("＋ New Quotation"){quoteScreen()};button("🧾 New Invoice"){invoiceScreen()};button("💵 Payment Collection"){paymentScreen()};button("🔔 Pending Payment Reminders"){remindersScreen()}}
    private fun quoteScreen(){setup("Quotation",::billingMenu);val no=edit("Quotation No", "QT-${SimpleDateFormat("yyyyMMdd-HHmm",Locale.getDefault()).format(Date())}");val d=edit("Date",now());val c=edit("Customer");val phone=edit("Mobile");val size=edit("System Size kW");val panel=edit("Panel / Quantity");val inv=edit("Inverter");val structure=edit("Structure");val install=edit("Installation charges ₹");val cable=edit("Cable / Accessories ₹");val transport=edit("Transport ₹");val discount=edit("Discount ₹");val gst=edit("GST %","18");button("Generate PDF + Share"){val sub=(install.text.toString().toDoubleOrNull()?:0.0)+(cable.text.toString().toDoubleOrNull()?:0.0)+(transport.text.toString().toDoubleOrNull()?:0.0);val total=(sub-(discount.text.toString().toDoubleOrNull()?:0.0))*(1+(gst.text.toString().toDoubleOrNull()?:0.0)/100);sharePdf("QUOTATION",listOf("No: ${no.text}","Date: ${d.text}","Customer: ${c.text}","Mobile: ${phone.text}","System: ${size.text} kW","Panel: ${panel.text}","Inverter: ${inv.text}","Structure: ${structure.text}","Installation: ${money(install.text.toString().toDoubleOrNull()?:0.0)}","Cable/Accessories: ${money(cable.text.toString().toDoubleOrNull()?:0.0)}","Transport: ${money(transport.text.toString().toDoubleOrNull()?:0.0)}","Discount: ${money(discount.text.toString().toDoubleOrNull()?:0.0)}","GST: ${gst.text}%","Grand Total: ${money(total)}","Terms: Quotation valid for 15 days."))}}
    private fun invoiceScreen(){setup("Tax Invoice",::billingMenu);val no=edit("Invoice No","INV-${SimpleDateFormat("yyyyMMdd-HHmm",Locale.getDefault()).format(Date())}");val c=edit("Customer");val phone=edit("Mobile");val desc=edit("Product / Service");val qty=edit("Quantity","1");val rate=edit("Rate ₹");val gst=edit("GST %","18");val paid=edit("Paid ₹");button("Generate Invoice PDF + Share"){val base=(qty.text.toString().toDoubleOrNull()?:1.0)*(rate.text.toString().toDoubleOrNull()?:0.0);val total=base*(1+(gst.text.toString().toDoubleOrNull()?:0.0)/100);sharePdf("TAX INVOICE",listOf("Invoice No: ${no.text}","Customer: ${c.text}","Mobile: ${phone.text}","Item: ${desc.text}","Qty: ${qty.text}","Rate: ${money(rate.text.toString().toDoubleOrNull()?:0.0)}","GST: ${gst.text}%","Grand Total: ${money(total)}","Paid: ${money(paid.text.toString().toDoubleOrNull()?:0.0)}","Balance: ${money(total-(paid.text.toString().toDoubleOrNull()?:0.0))}","For EDISON SOLAR • 6383287878"))}}
    private fun paymentScreen(){setup("Payment Collection",::billingMenu);val c=edit("Customer");val amount=edit("Payment ₹");val mode=edit("Mode (UPI/Cash/Bank)","UPI");val date=edit("Date",now());button("Save Payment"){jobs.add(Job(date.text.toString(),"Payment",c.text.toString(),"",0.0,amount.text.toString().toDoubleOrNull()?:0.0,0.0,0.0,"Payment"));save();Toast.makeText(this,"Payment saved • ${mode.text}",Toast.LENGTH_SHORT).show();billingMenu()}}

    private fun reports(){setup("Reports & Charts",::dashboard);val m=jobs.filter{it.date.endsWith(month())};val profit=m.sumOf{it.payment-it.expense-it.salary};card("Monthly Profit",money(profit),green);card("Installed kW",String.format(Locale.getDefault(),"%.2f",m.sumOf{it.kw}));card("Collection",money(m.sumOf{it.payment}));card("Expenses",money(m.sumOf{it.expense+it.salary}),orange);tv("Company-wise Profit",18f,true);companies.forEach{val x=m.filter{j->j.company==it.name}.sumOf{j->j.payment-j.expense-j.salary};tv("${it.name}  →  ${money(x)}")};tv("Date-wise history",18f,true);m.groupBy{it.date}.toSortedMap().entries.reversed().forEach{val x=it.value;tv("${it.key}: ${String.format(Locale.getDefault(),"%.2f",x.sumOf{j->j.kw})} kW • ${money(x.sumOf{j->j.payment})} collection • Profit ${money(x.sumOf{j->j.payment-j.expense-j.salary})}")};button("📤 Export CSV"){exportCsv()}}

    private fun stockScreen(){setup("Material Stock",::dashboard);stocks.forEach{tv("${it.name}  •  ${it.qty} ${it.unit}",17f,true)};val n=edit("Item name");val q=edit("Quantity");val u=edit("Unit","Nos");button("＋ Add Stock"){stocks.add(Stock(n.text.toString(),q.text.toString().toDoubleOrNull()?:0.0,u.text.toString()));save();stockScreen()}}
    private fun workerScreen(){setup("Worker Management",::dashboard);workers.forEach{tv("${it.name} • ${it.days} days • Salary ${money(it.salary)} • Advance ${money(it.advance)}")};val n=edit("Worker name");val d=edit("Days");val s=edit("Salary ₹");val a=edit("Advance ₹");button("＋ Add Worker"){workers.add(Worker(n.text.toString(),d.text.toString().toIntOrNull()?:0,s.text.toString().toDoubleOrNull()?:0.0,a.text.toString().toDoubleOrNull()?:0.0));save();workerScreen()}}
    private fun remindersScreen(){setup("Reminders",::dashboard);reminders.forEach{tv("🔔 ${it.title}\n${it.date} • ${money(it.amount)}",17f,true)};val t=edit("Reminder title");val d=edit("Due date",now());val a=edit("Amount ₹");button("＋ Add Reminder"){reminders.add(Reminder(t.text.toString(),d.text.toString(),a.text.toString().toDoubleOrNull()?:0.0));save();remindersScreen()}}
    private fun serviceScreen(){setup("Service & Maintenance",::dashboard);services.forEach{tv("${it.date} • ${it.customer}\n${it.note}")};val c=edit("Customer");val d=edit("Date",now());val n=edit("Service note");button("＋ Save Service"){services.add(Service(c.text.toString(),d.text.toString(),n.text.toString()));save();serviceScreen()}}

    private fun voiceEntry(){setup("Voice Entry",::dashboard);tv("Speak naturally. Example:\n‘Today ABC Company, Chennai Anna Nagar, Raja home, 5 kW installation, payment 75000, travel 300, salary 1500.’",17f,true);val out=tv("Ready for voice…",17f);button("🎙️ START VOICE INPUT"){voiceRequest=500;startVoice()};button("Save Parsed Entry"){Toast.makeText(this,"Use Preview/Edit after voice recognition, then save.",Toast.LENGTH_SHORT).show()};}
    private fun startVoice(){try{startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak site details")},voiceRequest)}catch(e:Exception){Toast.makeText(this,"Voice input unavailable",Toast.LENGTH_SHORT).show()}}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(res==RESULT_OK&&data!=null){
            if(req==201){(data.extras?.get("data") as? Bitmap)?.let{savePhoto(it);Toast.makeText(this,"Photo saved",Toast.LENGTH_SHORT).show()};return}
            val text=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if(req==501)installationFromVoice(text) else Toast.makeText(this,"Recognized: $text",Toast.LENGTH_LONG).show()
        }
    }
    private fun history(){
        setup("Site / Date History",::dashboard)
        val filter=edit("Filter date DD/MM/YYYY / customer / company")
        button("Search / Filter"){historyFiltered(filter.text.toString())}
        jobs.asReversed().take(100).forEach{jobCard(it)}
    }
    private fun historyFiltered(q:String){
        setup("Filtered History",::history)
        jobs.asReversed().filter{it.date.contains(q,true)||it.customer.contains(q,true)||it.company.contains(q,true)||it.site.contains(q,true)}.forEach{jobCard(it)}
    }
    private fun jobCard(j:Job){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(14,10,14,10);box.background=round(Color.WHITE,blue,1,14)
        val t=TextView(this);t.text="${j.date} • ${j.company}
${j.customer} • ${j.site}
${j.kw} kW • Collection ${money(j.payment)} • Expense ${money(j.expense+j.salary)}
NET PROFIT ${money(j.payment-j.expense-j.salary)}";t.textSize=15f;t.setTextColor(dark);box.addView(t)
        val row=LinearLayout(this);row.orientation=LinearLayout.HORIZONTAL
        val edit=Button(this);edit.text="Edit";edit.setOnClickListener{editJob(j)};row.addView(edit,LinearLayout.LayoutParams(0,50,1f))
        val del=Button(this);del.text="Delete";del.setOnClickListener{jobs.remove(j);save();history()};row.addView(del,LinearLayout.LayoutParams(0,50,1f))
        if(j.lat.isNotBlank()){val map=Button(this);map.text="Map";map.setOnClickListener{openMap(j.lat,j.lon)};row.addView(map,LinearLayout.LayoutParams(0,50,1f))}
        box.addView(row);content.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)})
    }
    private fun editJob(j:Job){
        setup("Edit Site Entry",::history)
        val d=edit("Date",j.date);val co=edit("Company",j.company);val cu=edit("Customer",j.customer);val site=edit("Area / Site",j.site);val kw=edit("Installed kW",j.kw.toString());val pay=edit("Customer Payment ₹",j.payment.toString());val ex=edit("Expense ₹",j.expense.toString());val sal=edit("Salary/Labour ₹",j.salary.toString());val note=edit("Notes",j.notes)
        button("📍 Update GPS"){captureLocation()};button("📸 Add / Replace Photo"){takePhoto()}
        button("Update Entry"){j.date=d.text.toString();j.company=co.text.toString();j.customer=cu.text.toString();j.site=site.text.toString();j.kw=kw.text.toString().toDoubleOrNull()?:j.kw;j.payment=pay.text.toString().toDoubleOrNull()?:j.payment;j.expense=ex.text.toString().toDoubleOrNull()?:j.expense;j.salary=sal.text.toString().toDoubleOrNull()?:j.salary;j.notes=note.text.toString();if(lat.isNotBlank())j.lat=lat;if(lon.isNotBlank())j.lon=lon;if(photoPath.isNotBlank())j.photoPath=photoPath;save();history()}
        button("🗑️ Delete Entry",{jobs.remove(j);save();history()},false)
    }
    private fun installationFromVoice(raw:String){setup("Voice Preview / Edit",::dashboard);val all=edit("Recognized text",raw);val co=edit("Company",companies.firstOrNull()?.name?:("Company 1"));val cu=edit("Customer");val site=edit("Area / Site");val kw=edit("kW",Regex("(\\d+(?:\\.\\d+)?)\\s*kW",RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1).orEmpty());val pay=edit("Payment ₹",Regex("(?:payment|paid|collection)[^0-9]*(\\d+(?:\\.\\d+)?)",RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1).orEmpty());val sal=edit("Salary ₹",Regex("salary[^0-9]*(\\d+(?:\\.\\d+)?)",RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1).orEmpty());val exp=edit("Travel/Expense ₹",Regex("(?:travel|expense)[^0-9]*(\\d+(?:\\.\\d+)?)",RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1).orEmpty());button("💾 Save Entry"){jobs.add(Job(now(),co.text.toString(),cu.text.toString(),site.text.toString(),kw.text.toString().toDoubleOrNull()?:0.0,pay.text.toString().toDoubleOrNull()?:0.0,exp.text.toString().toDoubleOrNull()?:0.0,sal.text.toString().toDoubleOrNull()?:0.0,"Voice",lat,lon,"Voice: ${all.text}",photoPath));save();dashboard()}}

    private fun captureLocation(){if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),10);return};LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener{l->if(l!=null){lat=l.latitude.toString();lon=l.longitude.toString();Toast.makeText(this,"GPS saved",Toast.LENGTH_SHORT).show()}else Toast.makeText(this,"Location unavailable",Toast.LENGTH_SHORT).show()}}
    private fun openMap(a:String,b:String){startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$a,$b?q=$a,$b")))}
    private fun takePhoto(){if(ActivityCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),20);return};startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE),201)}
    private fun savePhoto(bitmap:Bitmap){val dir=File(filesDir,"photos");dir.mkdirs();val f=File(dir,"site_${System.currentTimeMillis()}.jpg");FileOutputStream(f).use{bitmap.compress(Bitmap.CompressFormat.JPEG,88,it)};photoPath=f.absolutePath}

    private fun sharePdf(title:String,lines:List<String>){val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val p=Paint().apply{color=dark;textSize=18f;typeface=Typeface.DEFAULT_BOLD};c.drawText("EDISON SOLAR",40f,50f,p);p.textSize=12f;p.typeface=Typeface.DEFAULT;var y=80f;c.drawText("6383287878",40f,y,p);y+=35;c.drawText(title,40f,y,p);y+=28;lines.forEach{if(y>810f)return@forEach;c.drawText(it.take(90),40f,y,p);y+=20};doc.finishPage(page);val f=File(filesDir,"${title.lowercase(Locale.getDefault()).replace(" ","_")}_${System.currentTimeMillis()}.pdf");FileOutputStream(f).use{doc.writeTo(it)};doc.close();val uri=FileProvider.getUriForFile(this,"$packageName.fileprovider",f);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share $title"))}
    private fun exportCsv(){val f=File(filesDir,"edison_solar_report_${System.currentTimeMillis()}.csv");f.writeText(buildString{append("Date,Company,Customer,Site,kW,Payment,Expense,Salary,Net Profit,Latitude,Longitude\n");jobs.forEach{append(listOf(it.date,it.company,it.customer,it.site,it.kw,it.payment,it.expense,it.salary,it.payment-it.expense-it.salary,it.lat,it.lon).joinToString(","){v->"\"${v.toString().replace("\"","\"\"")}\""});append("\n")}});val uri=FileProvider.getUriForFile(this,"$packageName.fileprovider",f);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/csv";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Export Edison Solar CSV"))}
    private fun adminScreen(){setup("Admin & Backup",::dashboard);tv("EDISON SOLAR • 2 Admin access design\nBoth admins are intended to have full access to customers, sites, GPS, photos, voice, quotations, invoices, reports and payments.",17f,true);button("💾 Local Backup / Export"){exportCsv()};button("🔒 App Lock (PIN/Fingerprint)"){Toast.makeText(this,"Security screen placeholder — ready for PIN/biometric integration.",Toast.LENGTH_SHORT).show()};button("☁️ Cloud Sync Setup"){Toast.makeText(this,"Cloud sync needs your own Firebase/Supabase project credentials. This offline V2 does not ship shared credentials.",Toast.LENGTH_LONG).show()}}
}
