EDISON SOLAR FINAL BUILD FIX

Replace:
1) app/src/main/java/com/edisonsolar/worktracker/MainActivity.kt
2) .github/workflows/build-apk.yml

This fix addresses the Kotlin button-call ambiguity and the broken multiline job-card string, and keeps the ZIP extraction workflow.

The workflow expects an Android Gradle project ZIP in the repository root, as in the current GitHub setup.
