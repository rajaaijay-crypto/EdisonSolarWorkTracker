package com.edisonsolar.attendance

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

data class Worker(val id: Long, val name: String, val phone: String, val salary: Double, val type: String)

class DBHelper(ctx: Context) : android.database.sqlite.SQLiteOpenHelper(ctx, "edison.db", null, 1) {
    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,salary REAL,type TEXT)")
        db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,date TEXT,status TEXT)")
        db.execSQL("CREATE TABLE advances(id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,date TEXT,amount REAL,note TEXT)")
    }
    override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun workers(): List<Worker> {
        val out=mutableListOf<Worker>()
        readableDatabase.rawQuery("SELECT * FROM workers ORDER BY name",null).use { c ->
            while(c.moveToNext()) out.add(Worker(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4)))
        }
        return out
    }
    fun addWorker(name:String, phone:String, salary:Double, type:String) {
        val v=android.content.ContentValues().apply {
            put("name",name); put("phone",phone); put("salary",salary); put("type",type)
        }
        writableDatabase.insert("workers",null,v)
    }
    fun mark(workerId:Long,status:String) {
        val d=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
        val v=android.content.ContentValues().apply { put("worker_id",workerId); put("date",d); put("status",status) }
        writableDatabase.delete("attendance","worker_id=? AND date=?",arrayOf(workerId.toString(),d))
        writableDatabase.insert("attendance",null,v)
    }
    fun addAdvance(workerId:Long,amount:Double,note:String) {
        val d=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
        val v=android.content.ContentValues().apply { put("worker_id",workerId); put("date",d); put("amount",amount); put("note",note) }
        writableDatabase.insert("advances",null,v)
    }
    fun advanceTotal(workerId:Long):Double {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM advances WHERE worker_id=?",arrayOf(workerId.toString())).use { c ->
            return if(c.moveToFirst()) c.getDouble(0) else 0.0
        }
    }
}

class MainActivity : Activity() {
    private lateinit var db: DBHelper
    private lateinit var content: LinearLayout
    private val blue=Color.rgb(25,118,210)
    private val light=Color.rgb(227,242,253)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); db=DBHelper(this); showHome()
    }

    private fun base(title:String): LinearLayout {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar=TextView(this).apply {
            text="  ⚡ EDISON SOLAR\n  $title"; textSize=20f; setTextColor(Color.WHITE); setPadding(12,18,8,18); setBackgroundColor(blue)
        }
        root.addView(bar,LinearLayout.LayoutParams(-1,-2))
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,16,16,16) }
        val scroll=ScrollView(this); scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { setPadding(4,4,4,4); setBackgroundColor(light) }
        listOf("Home","Workers","Attendance","Salary").forEach { t ->
            val x=Button(this).apply { text=t; setOnClickListener { when(t){"Home"->showHome();"Workers"->showWorkers();"Attendance"->showAttendance();"Salary"->showSalary()} } }
            nav.addView(x,LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(nav)
        return root
    }
    private fun button(text:String, action:()->Unit)=Button(this).apply{this.text=text;setOnClickListener{action()}}
    private fun showHome(){
        val r=base("Dashboard"); content.addView(TextView(this).apply{text="Attendance • Salary • Advance";textSize=24f;setTextColor(blue)})
        val ws=db.workers(); content.addView(TextView(this).apply{text="\nWorkers: ${ws.size}\n\nToday: mark attendance from Attendance tab.\nAdvance: add from Salary tab.\nBalance: salary minus recorded advances.";textSize=18f})
        content.addView(button("＋ Add Worker"){showWorkers()})
    }
    private fun showWorkers(){
        val r=base("Workers"); content.addView(button("＋ Add Worker"){addWorkerDialog()})
        db.workers().forEach { w ->
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,12,12,12);setBackgroundColor(light)}
            box.addView(TextView(this).apply{text="${w.name}  •  ${w.type}\n${w.phone}\nSalary: ₹${"%.2f".format(w.salary)}";textSize=17f})
            content.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,0)})
        }
        setContentView(r)
    }
    private fun addWorkerDialog(){
        val lay=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding(20)}
        val name=EditText(this); name.hint="Worker name"
        val phone=EditText(this); phone.hint="Mobile"
        val sal=EditText(this); sal.hint="Salary amount"; sal.inputType=2
        val type=EditText(this); type.hint="Daily / Monthly"
        listOf(name,phone,sal,type).forEach{lay.addView(it)}
        AlertDialog.Builder(this).setTitle("Add Worker").setView(lay).setPositiveButton("Save"){_,_->
            db.addWorker(name.text.toString(),phone.text.toString(),sal.text.toString().toDoubleOrNull()?:0.0,type.text.toString().ifBlank{"Monthly"});showWorkers()
        }.setNegativeButton("Cancel",null).show()
    }
    private fun showAttendance(){
        val r=base("Today's Attendance")
        db.workers().forEach { w ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8)}
            row.addView(TextView(this).apply{text=w.name;textSize=18f})
            val buttons=LinearLayout(this)
            listOf("Present","Absent","Half Day").forEach{s->buttons.addView(button(s){db.mark(w.id,s);Toast.makeText(this,"${w.name}: $s",Toast.LENGTH_SHORT).show()})}
            row.addView(buttons);content.addView(row)
        }
        setContentView(r)
    }
    private fun showSalary(){
        val r=base("Salary & Advance")
        db.workers().forEach { w ->
            val adv=db.advanceTotal(w.id)
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,12,12,12);setBackgroundColor(light)}
            box.addView(TextView(this).apply{text="${w.name}\nSalary: ₹${"%.2f".format(w.salary)}\nAdvance: ₹${"%.2f".format(adv)}\nRecorded balance: ₹${"%.2f".format(w.salary-adv)}";textSize=17f})
            box.addView(button("＋ Add Advance"){advanceDialog(w)})
            content.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,0)})
        }
        setContentView(r)
    }
    private fun advanceDialog(w:Worker){
        val lay=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding(20)}
        val amt=EditText(this);amt.hint="Advance amount";amt.inputType=2
        val note=EditText(this);note.hint="Note"
        lay.addView(amt);lay.addView(note)
        AlertDialog.Builder(this).setTitle("Advance • ${w.name}").setView(lay).setPositiveButton("Save"){_,_->
            val a=amt.text.toString().toDoubleOrNull()?:0.0;db.addAdvance(w.id,a,note.text.toString());showSalary()
        }.setNegativeButton("Cancel",null).show()
    }
}
