# EDISON SOLAR Attendance + Salary + Advance

Features in this starter app:
- Worker list
- Daily attendance: Present / Absent / Half Day
- Daily or monthly salary
- Advance entry
- Automatic balance calculation
- Monthly summary
- Local offline SQLite storage
- Light-blue Edison Solar style

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

The approved Edison Solar logo was not available in this build environment, so a simple temporary icon is included. Replace it with the final logo before release.
