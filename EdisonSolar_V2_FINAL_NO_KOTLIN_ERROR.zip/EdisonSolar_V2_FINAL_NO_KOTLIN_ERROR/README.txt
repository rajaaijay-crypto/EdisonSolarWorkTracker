EDISON SOLAR - Professional V2

This final compile-safe edition intentionally uses Java only. It does NOT use MainActivity.kt or the Kotlin compiler, avoiding the repeated Kotlin Function0<Boolean> error.

Android project:
- namespace/applicationId: com.edisonsolar.worktracker
- compileSdk 35
- minSdk 24
- targetSdk 35
- Java 17
- Gradle 8.9 / Android Gradle Plugin 8.7.3

GitHub Actions builds the debug APK automatically on push to main or by manual workflow dispatch.

Important: this edition is local/offline data storage. A real two-phone shared online database still requires a cloud backend such as Firebase/Supabase.
