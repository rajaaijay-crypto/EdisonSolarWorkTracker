# EDISON SOLAR Professional V2

Android solar business management app prototype, designed around the approved light-blue/white mockup.

Included modules: visual graph dashboard (6-month collection, expense, profit, company profit, system-size distribution and payment-status charts), dashboard, site installation, customers, companies, GPS/Maps, camera photos, voice entry, quotations, invoices, reports, expenses, workers, stock, reminders, service history, search, CSV export and PDF sharing.

This build stores data locally on the phone. Graphs are generated from the app's saved data and update automatically. Two-admin cloud synchronization requires connecting a Firebase/Supabase project with the owner's credentials; the app does not include shared credentials.

Build with GitHub Actions using the workflow in `.github/workflows/build-apk.yml`.


## V2.1 Voice Assistant
- Global microphone button is available from every app screen.
- Supports Android Speech Recognizer with Tamil (`ta-IN`) and English/Tanglish (`en-IN`) modes.
- Voice commands can create leads, customers, site/installation entries, payments, stock, workers, reminders, and service entries.
- Voice can generate quotation and invoice PDFs.
- Existing installation voice-fill remains supported.
- Voice-created data is stored using the same local storage as the app and therefore appears in the existing graphs/reports.
- Microphone permission (`RECORD_AUDIO`) is required.
- This remains local/offline storage; real-time two-person online sync still requires a Firebase/Supabase backend and credentials.

Example commands:
- “Ramesh customer, 6383287878, Tambaram, 3 kW”
- “Ramesh payment 50000 UPI”
- “ABC site, 5 kW, payment 75000, expense 300, salary 1500”
- “10 panels stock add”
- “Suresh worker, 5 days, salary 4500, advance 1000”
- “Tomorrow Ramesh follow up reminder”
- “Ramesh service tomorrow inverter check”
- “Ramesh 3 kW quotation”
- “Ramesh invoice, solar installation, 85000”
