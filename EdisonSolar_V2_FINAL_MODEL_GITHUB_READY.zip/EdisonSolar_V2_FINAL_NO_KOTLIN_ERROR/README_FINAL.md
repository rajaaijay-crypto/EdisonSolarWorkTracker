EDISON SOLAR V2 - FINAL MODEL 2451

This project is packaged for the existing GitHub Actions workflow that expects:
EdisonSolar_V2_FINAL_NO_KOTLIN_ERROR.zip

UI reference: 2451.jpg / FINAL_MODEL_2451.jpg
Version: 2.1-FINAL-2451

Main UI modules: Dashboard, Customers, Leads/Follow-up, Quotation, Invoice/Payment, Installation/Site Survey, Stock, Workers, Reminders, Service, Reports & Graphs, Settings/Backup, Side Menu.
