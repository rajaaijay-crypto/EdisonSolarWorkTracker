# EDISON SOLAR MANAGER PRO – V18.1

Based on the V18 project with the requested monthly worker report update.

## Worker Monthly Report
- Select/open a month in YYYY-MM format.
- Shows every worker for the selected month.
- Present / Half Day / Absent counts.
- Half Day salary = 50% of daily salary.
- Monthly salary is used when monthly salary is configured.
- Shows calculated salary, advance, paid salary, and pending balance.
- Add salary payment for a worker.
- Add advance for a worker.
- View separate payment history and advance history for the selected worker/month.
- Attendance history is also shown for that worker/month.
- Monthly salary PDF and WhatsApp/share remain available.

Database version is 5 and automatically creates the `salary_payments` table on upgrade.
