package com.edisonsolar.businesspro;

class Company {
    int id;
    String name = "";
    String phone = "";
}

class Project {
    int id;
    int companyId;
    String number = "";
    String company = "";
    String customer = "";
    String phone = "";
    String site = "";
    double kw;
    double amount;
    String date = "";
    String status = "";
    String work = "";
    double lat;
    double lon;
    boolean hasLoc;
}

class Worker {
    int id;
    String name = "";
    String phone = "";
    double dailySalary;
    double monthlySalary;
}
