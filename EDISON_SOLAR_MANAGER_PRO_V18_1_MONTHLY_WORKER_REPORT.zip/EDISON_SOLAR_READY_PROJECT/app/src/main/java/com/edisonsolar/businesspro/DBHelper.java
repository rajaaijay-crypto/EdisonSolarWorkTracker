package com.edisonsolar.businesspro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Locale;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "edison_solar_manager.db";
    private static final int DB_VERSION = 5;

    public DBHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE companies (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT)");
        db.execSQL("CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER DEFAULT 0,number TEXT,company TEXT,customer TEXT,phone TEXT,site TEXT,kw REAL DEFAULT 0,amount REAL DEFAULT 0,date TEXT,status TEXT,work TEXT,lat REAL DEFAULT 0,lon REAL DEFAULT 0,has_location INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE payments (id INTEGER PRIMARY KEY AUTOINCREMENT,project_id INTEGER,amount REAL DEFAULT 0,date TEXT,mode TEXT,note TEXT)");
        db.execSQL("CREATE TABLE expenses (id INTEGER PRIMARY KEY AUTOINCREMENT,project_id INTEGER,category TEXT,amount REAL DEFAULT 0,date TEXT,note TEXT)");
        db.execSQL("CREATE TABLE photos (id INTEGER PRIMARY KEY AUTOINCREMENT,project_id INTEGER,uri TEXT)");
        db.execSQL("CREATE TABLE workers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,daily_salary REAL DEFAULT 0,monthly_salary REAL DEFAULT 0)");
        db.execSQL("CREATE TABLE attendance (id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,date TEXT,status TEXT,site TEXT,note TEXT,UNIQUE(worker_id,date))");
        db.execSQL("CREATE TABLE advances (id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,amount REAL DEFAULT 0,date TEXT,note TEXT)");
        db.execSQL("CREATE TABLE salary_payments (id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,amount REAL DEFAULT 0,date TEXT,note TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        if (oldVersion < 4) {
            db.execSQL("CREATE TABLE IF NOT EXISTS workers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,daily_salary REAL DEFAULT 0,monthly_salary REAL DEFAULT 0)");
            db.execSQL("CREATE TABLE IF NOT EXISTS attendance (id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,date TEXT,status TEXT,site TEXT,note TEXT,UNIQUE(worker_id,date))");
            db.execSQL("CREATE TABLE IF NOT EXISTS advances (id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,amount REAL DEFAULT 0,date TEXT,note TEXT)");
        }
        if (oldVersion < 5) {
            db.execSQL("CREATE TABLE IF NOT EXISTS salary_payments (id INTEGER PRIMARY KEY AUTOINCREMENT,worker_id INTEGER,amount REAL DEFAULT 0,date TEXT,note TEXT)");
        }
    }

    public ArrayList<Project> projects(){
        ArrayList<Project> list=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,company_id,number,company,customer,phone,site,kw,amount,date,status,work,lat,lon,has_location FROM projects ORDER BY id DESC",null);
        while(c.moveToNext()) list.add(readProject(c)); c.close(); return list;
    }

    private Project readProject(Cursor c){
        Project p=new Project();
        p.id=c.getInt(0); p.companyId=c.getInt(1); p.number=safe(c.getString(2)); p.company=safe(c.getString(3));
        p.customer=safe(c.getString(4)); p.phone=safe(c.getString(5)); p.site=safe(c.getString(6)); p.kw=c.getDouble(7); p.amount=c.getDouble(8);
        p.date=safe(c.getString(9)); p.status=safe(c.getString(10)); p.work=safe(c.getString(11)); p.lat=c.getDouble(12); p.lon=c.getDouble(13); p.hasLoc=c.getInt(14)==1;
        return p;
    }

    public void saveSalaryPayment(int workerId,double amount,String date,String note){
        ContentValues v=new ContentValues();
        v.put("worker_id",workerId);
        v.put("amount",amount);
        v.put("date",date);
        v.put("note",note);
        getWritableDatabase().insert("salary_payments",null,v);
    }

    public double salaryPayments(int workerId,String month){
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM salary_payments WHERE worker_id=? AND date LIKE ?",new String[]{""+workerId,month+"%"});
        double x=c.moveToFirst()?c.getDouble(0):0; c.close(); return x;
    }

    public double advancesForMonth(int workerId,String month){
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM advances WHERE worker_id=? AND date LIKE ?",new String[]{""+workerId,month+"%"});
        double x=c.moveToFirst()?c.getDouble(0):0; c.close(); return x;
    }

    public String salaryReport(int workerId,String month){
        Cursor w=getReadableDatabase().rawQuery("SELECT name,daily_salary,monthly_salary FROM workers WHERE id=?",new String[]{""+workerId});
        if(!w.moveToFirst()){w.close();return "";}
        String name=safe(w.getString(0)); double daily=w.getDouble(1), monthly=w.getDouble(2); w.close();
        int present=countStatus(workerId,month,"Present"), half=countStatus(workerId,month,"Half Day"), absent=countStatus(workerId,month,"Absent");
        double salary=monthly>0?monthly:daily*(present+half*0.5);
        double advance=advancesForMonth(workerId,month);
        double paid=salaryPayments(workerId,month);
        return "WORKER: "+name+"\nPresent: "+present+"\nHalf Day: "+half+"\nAbsent: "+absent+"\nDaily Salary: ₹"+fmt(daily)+"\nMonthly Salary: ₹"+fmt(monthly)+"\nSalary: ₹"+fmt(salary)+"\nAdvance: ₹"+fmt(advance)+"\nPaid: ₹"+fmt(paid)+"\nBALANCE: ₹"+fmt(Math.max(0,salary-advance-paid));
    }

    private int countStatus(int workerId,String month,String status){
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM attendance WHERE worker_id=? AND date LIKE ? AND status=?",new String[]{""+workerId,month+"%",status});
        int x=c.moveToFirst()?c.getInt(0):0; c.close(); return x;
    }

    public static String fmt(double value){
        if(Math.abs(value-Math.round(value))<0.00001) return String.format(Locale.getDefault(),"%.0f",value);
        return String.format(Locale.getDefault(),"%.2f",value);
    }
    private String safe(String s){return s==null?"":s;}
}
