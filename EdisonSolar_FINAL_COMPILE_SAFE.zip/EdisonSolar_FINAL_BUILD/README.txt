EDISON SOLAR PROFESSIONAL V2 - FINAL COMPILE-SAFE BUILD

This edition intentionally uses plain Java + Android SDK and no Kotlin code, so the repeated Kotlin compile errors are removed.

IMPORTANT:
1. Upload the CONTENTS of this folder to the ROOT of your GitHub repository.
2. Do NOT upload this whole folder as a nested folder.
3. Repository root must directly contain:
   settings.gradle
   build.gradle
   gradle.properties
   app/
   .github/workflows/build-apk.yml
4. Run Actions -> Build Edison Solar APK.
5. Download the artifact named EdisonSolar-V2-debug-APK.

This build is local/offline data storage. A real 2-person shared online database requires Firebase/Supabase credentials and is a separate connection step.
