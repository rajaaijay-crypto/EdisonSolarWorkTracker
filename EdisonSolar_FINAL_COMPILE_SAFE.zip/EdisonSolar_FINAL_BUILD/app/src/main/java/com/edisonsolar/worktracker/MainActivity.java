package com.edisonsolar.worktracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, content;
    private SharedPreferences prefs;
    private int blue = Color.rgb(13,71,161), green = Color.rgb(46,125,50), orange = Color.rgb(239,108,0);
    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private TextView tv(String text, float size){ TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.DKGRAY); t.setPadding(dp(12),dp(8),dp(12),dp(8)); return t; }
    private Button btn(String text){ Button b=new Button(this); b.setText(text); b.setAllCaps(false); return b; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("edison_solar",MODE_PRIVATE); showDashboard(); }

    private void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(248,250,252));
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),dp(4),dp(8),dp(4)); bar.setBackgroundColor(blue);
        TextView t=tv(title,20); t.setTextColor(Color.WHITE); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); bar.addView(t,new LinearLayout.LayoutParams(0,dp(56),1));
        Button home=btn("Home"); home.setOnClickListener(v->showDashboard()); bar.addView(home,new LinearLayout.LayoutParams(dp(82),dp(52)));
        root.addView(bar); ScrollView sc=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(10),dp(10),dp(10),dp(20)); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void showDashboard(){
        base("EDISON SOLAR • V2");
        TextView welcome=tv("Solar Business Management",22); welcome.setTypeface(Typeface.DEFAULT,Typeface.BOLD); welcome.setTextColor(blue); content.addView(welcome);
        content.addView(tv("Phone: 6383287878",14));
        addCard("Customers", "Customer database, phone, address, kW, paid & pending", v->customers());
        addCard("Leads / Follow-up", "Lead entry, status and follow-up tracking", v->simpleForm("New Lead", new String[]{"Customer Name","Phone","Requirement kW","Follow-up Date"},"Lead saved"));
        addCard("Quotation", "Create quotation details and save locally", v->simpleForm("Quotation",new String[]{"Customer","System kW","Panel / Inverter","Total Amount"},"Quotation saved"));
        addCard("Invoice / Payment", "Received, pending and payment history", v->simpleForm("Payment",new String[]{"Customer","Amount Received","Payment Date","Mode"},"Payment saved"));
        addCard("Installation / Site Survey", "Site details, kW and installation status", v->simpleForm("Installation",new String[]{"Customer","Site","System kW","Status"},"Installation saved"));
        addCard("Stock", "Panels, inverter, cable and other materials", v->simpleForm("Stock",new String[]{"Material","Quantity","Unit","Purchase Rate"},"Stock saved"));
        addCard("Workers", "Worker days, salary and advance", v->simpleForm("Worker",new String[]{"Worker Name","Days","Salary","Advance"},"Worker saved"));
        addCard("Service / AMC", "Service date, customer and notes", v->simpleForm("Service",new String[]{"Customer","Service Date","Issue / Note"},"Service saved"));
        addCard("Reminders", "Follow-up and payment reminders", v->simpleForm("Reminder",new String[]{"Title","Date","Amount / Note"},"Reminder saved"));
        addCard("GRAPH DASHBOARD", "Collection, expenses, profit and capacity charts", v->graphs());
        addCard("Reports", "Business summary and export-ready view", v->reports());
    }

    private void addCard(String title,String desc,View.OnClickListener l){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(8),dp(4),dp(8),dp(4));
        TextView h=tv(title,18); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); h.setTextColor(blue); c.addView(h); c.addView(tv(desc,13)); Button b=btn("Open"); b.setOnClickListener(l); c.addView(b); content.addView(c,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void customers(){
        base("Customers"); content.addView(tv("Saved customer entries",20));
        Button add=btn("+ Add Customer"); add.setOnClickListener(v->simpleForm("Customer",new String[]{"Name","Phone","Address","Company","System kW","Paid","Pending"},"Customer saved")); content.addView(add);
        content.addView(tv("Data is stored safely on this phone in this compile-safe edition.",13));
    }

    private void simpleForm(String title,String[] fields,String success){
        base(title); final EditText[] es=new EditText[fields.length];
        for(int i=0;i<fields.length;i++){ es[i]=new EditText(this); es[i].setHint(fields[i]); es[i].setSingleLine(true); es[i].setPadding(dp(12),dp(10),dp(12),dp(10)); content.addView(es[i],new LinearLayout.LayoutParams(-1,dp(58))); }
        Button save=btn("SAVE"); save.setOnClickListener(v->{ StringBuilder s=new StringBuilder(); for(int i=0;i<fields.length;i++){ String x=es[i].getText().toString().trim(); if(x.length()>0) s.append(fields[i]).append(": ").append(x).append("\n"); } prefs.edit().putString(title+"_"+System.currentTimeMillis(),s.toString()).apply(); Toast.makeText(this,success,Toast.LENGTH_SHORT).show(); }); content.addView(save);
    }

    private void graphs(){
        base("Graph Dashboard");
        content.addView(tv("Business Graphs",22));
        content.addView(tv("Sample dashboard — charts update from saved app data in the full data edition.",13));
        addChart("6-Month Collection", new float[]{35,48,42,60,72,88});
        addChart("6-Month Profit", new float[]{18,24,20,34,39,51});
        addChart("Monthly Expenses", new float[]{15,22,18,28,25,30});
        addChart("System Capacity (kW)", new float[]{12,18,10,7,4,2});
    }

    private void addChart(String title,float[] data){
        TextView h=tv(title,17); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD); content.addView(h); content.addView(new ChartView(this,data),new LinearLayout.LayoutParams(-1,dp(190))); }

    private void reports(){
        base("Reports"); content.addView(tv("EDISON SOLAR REPORT",22));
        content.addView(tv("Revenue\nCollection\nExpenses\nProfit\nCustomers\nPending Payments\nInstallations\nSystem Capacity\nFollow-ups\nWorkers / Salary\nStock",17));
        Button b=btn("Show Graph Dashboard"); b.setOnClickListener(v->graphs()); content.addView(b);
    }

    private class ChartView extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float[] d;
        ChartView(Context c,float[] x){super(c);d=x;p.setStrokeWidth(dp(3));setBackgroundColor(Color.WHITE);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); if(d.length==0)return; float max=1; for(float x:d)max=Math.max(max,x); float w=getWidth()-dp(28), h=getHeight()-dp(28); Path path=new Path(); p.setColor(blue); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); for(int i=0;i<d.length;i++){float x=dp(14)+w*i/(d.length-1);float y=dp(14)+h-(d[i]/max)*h;if(i==0)path.moveTo(x,y);else path.lineTo(x,y); c.drawCircle(x,y,dp(4),p);} c.drawPath(path,p); p.setStyle(Paint.Style.FILL); p.setTextSize(dp(11)); p.setColor(Color.DKGRAY); c.drawText("0",dp(4),getHeight()-dp(8),p); c.drawText("Max",dp(4),dp(18),p); }
    }
}
